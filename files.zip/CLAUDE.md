# CLAUDE.md - Elon Tweet Bot Master Specification

## Project Overview

You are building **ElonBot**, an automated trading bot that monitors Elon Musk's tweet activity and trades on Polymarket's tweet count prediction markets. The bot uses the xTracker API (Polymarket's official tweet counter) to track tweets and places bets on multiple concurrent markets with different timeframes.

**Location:** `/home/user/elonbot/`
**Dashboard Port:** 5025
**Database:** SQLite at `/home/user/elonbot/data/elonbot.db`

---

## Core Strategy

The bot replicates the strategy used by successful traders like @Annica ($271K+ profit):

1. **Early Entry:** Enter markets within the first 36 hours (weekly) or 12 hours (short-term) when bucket prices are cheap (3-10¢)
2. **Wide Spread:** Buy 6-10 buckets around the projected tweet count range
3. **Hold to Resolution:** Don't sell early unless price exceeds 50¢
4. **Adaptive Learning:** Improve projections over time based on actual results

---

## Architecture

```
elonbot/
├── CLAUDE.md                # This file - master specification
├── config/
│   ├── settings.py          # Default config values
│   └── .env                  # API keys (gitignored)
│
├── core/
│   ├── __init__.py
│   ├── market_scanner.py    # Find & parse Polymarket markets
│   ├── xtracker_client.py   # Fetch tweet counts from xTracker API
│   ├── projection_engine.py # Adaptive learning & projections
│   ├── entry_manager.py     # Decide when/what to buy
│   ├── position_manager.py  # Track positions, P/L, exits
│   └── portfolio_manager.py # Cross-market risk management
│
├── polymarket/
│   ├── __init__.py
│   ├── client.py            # API wrapper (authentication, requests)
│   ├── orders.py            # Place/cancel orders
│   └── claims.py            # Claim resolved positions
│
├── db/
│   ├── __init__.py
│   ├── database.py          # SQLite connection & helpers
│   └── models.py            # Table definitions
│
├── dashboard/
│   ├── __init__.py
│   ├── app.py               # FastAPI server on port 5025
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── api.py           # JSON endpoints for frontend
│   │   └── controls.py      # Bot on/off, settings updates
│   ├── templates/
│   │   └── index.html       # Main dashboard page
│   └── static/
│       ├── style.css
│       └── app.js           # Real-time updates
│
├── data/
│   └── elonbot.db           # SQLite database (created at runtime)
│
├── logs/
│   └── bot.log              # Log file
│
├── bot.py                   # Main orchestrator
├── scheduler.py             # APScheduler for timed tasks
├── requirements.txt
└── README.md
```

---

## Database Schema

Create this schema in `/home/user/elonbot/db/models.py` and initialize in `database.py`:

```sql
-- Markets we're tracking
CREATE TABLE IF NOT EXISTS markets (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    duration_days INTEGER NOT NULL,
    duration_type TEXT NOT NULL CHECK (duration_type IN ('weekly', 'short')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'resolved', 'cancelled')),
    winning_bucket TEXT,
    final_count INTEGER,
    our_projection INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Our positions in each market
CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    bucket_range TEXT NOT NULL,
    side TEXT NOT NULL DEFAULT 'yes' CHECK (side IN ('yes', 'no')),
    shares REAL NOT NULL,
    avg_price REAL NOT NULL,
    cost_basis REAL NOT NULL,
    current_price REAL,
    current_value REAL,
    unrealized_pnl REAL,
    realized_pnl REAL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'sold', 'won', 'lost', 'claimed')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    closed_at DATETIME,
    FOREIGN KEY (market_id) REFERENCES markets(id),
    UNIQUE(market_id, bucket_range, side)
);

-- Individual trade executions
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    bucket_range TEXT NOT NULL,
    side TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
    shares REAL NOT NULL,
    price REAL NOT NULL,
    total REAL NOT NULL,
    order_type TEXT DEFAULT 'limit' CHECK (order_type IN ('limit', 'market')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'filled', 'partial', 'cancelled', 'failed')),
    polymarket_order_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    filled_at DATETIME,
    FOREIGN KEY (market_id) REFERENCES markets(id)
);

-- Tweet count snapshots for each market
CREATE TABLE IF NOT EXISTS tweet_counts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    count INTEGER NOT NULL,
    hours_elapsed REAL NOT NULL,
    projected_final INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (market_id) REFERENCES markets(id)
);

-- Daily tweet aggregates for learning
CREATE TABLE IF NOT EXISTS daily_stats (
    date DATE PRIMARY KEY,
    total_tweets INTEGER NOT NULL,
    day_of_week INTEGER NOT NULL,
    rolling_7day_avg REAL,
    rolling_30day_avg REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Projection accuracy tracking for adaptive learning
CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL UNIQUE,
    predicted_center INTEGER NOT NULL,
    predicted_low INTEGER NOT NULL,
    predicted_high INTEGER NOT NULL,
    actual INTEGER,
    error INTEGER,
    within_range BOOLEAN,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    FOREIGN KEY (market_id) REFERENCES markets(id)
);

-- Bot settings (adjustable via dashboard)
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Activity log for dashboard
CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    message TEXT NOT NULL,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default settings
INSERT OR IGNORE INTO settings (key, value) VALUES
    ('bot_enabled', 'true'),
    ('max_exposure', '200'),
    ('bet_size_per_bucket', '10'),
    ('play_weekly_markets', 'true'),
    ('play_short_term_markets', 'true'),
    ('max_entry_price_weekly', '0.10'),
    ('max_entry_price_short', '0.12'),
    ('entry_window_weekly', '36'),
    ('entry_window_short', '12'),
    ('min_buckets_to_enter', '5'),
    ('max_buckets_per_market', '10'),
    ('early_exit_threshold', '0.50'),
    ('scan_interval_minutes', '30');
```

---

## Component Specifications

### 1. xTracker Client (`core/xtracker_client.py`)

Fetches tweet data from xTracker API (Polymarket's official resolution source).

**Base URL:** `https://xtracker.polymarket.com/api`

**Endpoints to use:**
- `GET /users/elonmusk` - Get Elon's profile and total post count
- `GET /users/elonmusk/trackings` - Get all tracking periods (market windows)
- `GET /trackings/{id}?includeStats=true` - Get specific tracking period with stats
- `GET /metrics/{userId}?type=daily&startDate=X&endDate=Y` - Get daily metrics

**Implementation:**
```python
class XTrackerClient:
    BASE_URL = "https://xtracker.polymarket.com/api"
    
    async def get_user(self, handle: str = "elonmusk") -> dict
    async def get_active_trackings(self, handle: str = "elonmusk") -> list
    async def get_tracking(self, tracking_id: str, include_stats: bool = True) -> dict
    async def get_daily_metrics(self, user_id: str, start_date: date, end_date: date) -> list
    async def get_current_count_for_period(self, start_date: datetime, end_date: datetime) -> int
```

**Response format:**
```json
{
  "success": true,
  "data": { ... }
}
```

---

### 2. Market Scanner (`core/market_scanner.py`)

Finds and parses all active Elon tweet markets on Polymarket.

**Responsibilities:**
- Search Polymarket for "elon musk tweets" markets
- Parse market titles to extract date ranges
- Calculate duration (weekly vs short-term)
- Fetch current bucket prices for each market
- Categorize markets: entry_opportunity / active_position / watch_only / ending_soon

**Market title format:** `"Elon Musk # tweets January 20 - January 27, 2026?"`

**Implementation:**
```python
class MarketScanner:
    def __init__(self, polymarket_client, db)
    
    async def scan_all_markets(self) -> list[dict]
    def parse_market_title(self, title: str) -> tuple[datetime, datetime] | None
    def calculate_duration_type(self, days: int) -> str  # 'weekly' or 'short'
    async def get_bucket_prices(self, market_id: str) -> dict[str, dict]
    def categorize_markets(self, markets: list, positions: list) -> dict
```

**Bucket price structure:**
```python
{
    "520-539": {"yes_price": 0.11, "no_price": 0.89, "volume": 47000},
    "540-559": {"yes_price": 0.11, "no_price": 0.89, "volume": 52000},
    ...
}
```

---

### 3. Projection Engine (`core/projection_engine.py`)

Adaptive learning system that improves tweet count predictions over time.

**Cold start defaults:**
- Weekly mean: 550 tweets
- Weekly std: 100 tweets
- Daily mean: 78 tweets

**Signals used for projection:**
1. Historical all-time average
2. Recent 4-week average (with trend detection)
3. Current pace (tweets so far / hours elapsed)

**Adaptive weights** (adjusted based on prediction accuracy):
```python
weights = {
    "historical_mean": 0.25,
    "recent_4week_avg": 0.35,
    "current_pace": 0.40,  # Increases as week progresses
}
```

**Implementation:**
```python
class ProjectionEngine:
    def __init__(self, db)
    
    def get_historical_stats(self) -> dict
    def detect_trend(self) -> float  # Multiplier: >1 = increasing, <1 = decreasing
    def project_count(self, market: dict, current_count: int, hours_elapsed: float) -> dict
    def select_buckets(self, projection: dict, bucket_prices: dict, config: dict) -> list
    def learn_from_result(self, market_id: str, predicted: int, actual: int) -> None
```

**Projection output:**
```python
{
    "center": 547,
    "low": 480,
    "high": 614,
    "confidence": 0.65,
    "trend_multiplier": 1.05,
    "signals": {
        "historical_mean": 550,
        "recent_4week_avg": 562,
        "pace_projection": 534,
    }
}
```

---

### 4. Entry Manager (`core/entry_manager.py`)

Decides when and what to buy for each market.

**Entry criteria (ALL must be met):**
1. Market is within entry window (36h weekly / 12h short)
2. At least `min_buckets_to_enter` (default 5) buckets below max entry price
3. Portfolio exposure + new position ≤ max exposure
4. Bot is enabled
5. We don't already have positions in this market

**Bucket selection logic:**
1. Get projection from ProjectionEngine
2. Filter buckets within [projection.low - 40, projection.high + 40]
3. Filter buckets with price ≤ max_entry_price
4. Sort by distance from projection.center (closest first)
5. Take top `max_buckets_per_market` buckets

**Implementation:**
```python
class EntryManager:
    def __init__(self, projection_engine, portfolio_manager, polymarket_client, db)
    
    async def check_entry_opportunity(self, market: dict) -> dict | None
    async def execute_entry(self, market: dict, buckets: list) -> list[dict]
    def calculate_position_size(self, bucket_price: float, bet_size: float) -> float
```

---

### 5. Position Manager (`core/position_manager.py`)

Tracks all positions and handles exits.

**Responsibilities:**
- Create position records when orders fill
- Update current prices and P/L regularly
- Detect when markets resolve
- Trigger claims for winning positions
- Update position status (won/lost/claimed)

**Implementation:**
```python
class PositionManager:
    def __init__(self, polymarket_client, db)
    
    async def create_position(self, market_id: str, bucket: str, shares: float, price: float) -> int
    async def update_all_positions(self) -> None
    async def check_exits(self) -> list[dict]  # Returns positions to exit
    async def handle_resolution(self, market_id: str, winning_bucket: str) -> None
    async def claim_winnings(self, position_id: int) -> bool
    def get_position_summary(self) -> dict
```

---

### 6. Portfolio Manager (`core/portfolio_manager.py`)

Cross-market risk management.

**Tracks:**
- Total cash available
- Total deployed capital
- Exposure by market type (weekly / short)
- Number of active markets

**Implementation:**
```python
class PortfolioManager:
    def __init__(self, polymarket_client, db)
    
    async def get_cash_balance(self) -> float
    def get_total_exposure(self) -> float
    def get_exposure_by_type(self, market_type: str) -> float
    def can_enter_market(self, proposed_exposure: float) -> tuple[bool, str]
    def get_portfolio_summary(self) -> dict
```

---

### 7. Polymarket Client (`polymarket/client.py`)

**Note:** This requires the user's existing Polymarket API credentials and integration code from their sportsbot project. The client should support:

```python
class PolymarketClient:
    def __init__(self, api_key: str, api_secret: str, ...)
    
    async def search_markets(self, query: str, status: str = "active") -> list
    async def get_market(self, market_id: str) -> dict
    async def get_market_prices(self, market_id: str) -> dict
    async def get_orderbook(self, market_id: str, bucket: str) -> dict
    async def place_limit_order(self, market_id: str, bucket: str, side: str, shares: float, price: float) -> dict
    async def cancel_order(self, order_id: str) -> bool
    async def get_positions(self) -> list
    async def claim_winnings(self, market_id: str, bucket: str) -> bool
    async def get_balance(self) -> dict
```

---

### 8. Dashboard (`dashboard/app.py`)

FastAPI server running on port 5025.

**Endpoints:**

```
GET  /                     - Main dashboard HTML page
GET  /api/portfolio        - Portfolio summary
GET  /api/markets          - All markets with status
GET  /api/positions        - All positions with P/L
GET  /api/settings         - Current bot settings
POST /api/settings         - Update settings
POST /api/bot/toggle       - Enable/disable bot
POST /api/bot/scan         - Trigger manual market scan
POST /api/market/{id}/enter - Manual entry into market
POST /api/claims/all       - Claim all resolved winnings
GET  /api/activity         - Recent activity log
GET  /api/stats            - Historical performance stats
```

**Dashboard features:**
- Real-time portfolio value and P/L
- All active markets with current tweet counts
- Entry opportunities highlighted with "Enter" buttons
- Position details per market with bucket breakdown
- Bot ON/OFF toggle
- Settings controls (max exposure, bet size, market types)
- Activity log showing recent actions
- Performance charts

---

### 9. Bot Orchestrator (`bot.py`)

Main loop that coordinates all components.

**Scheduled tasks:**
- Every 30 minutes: Scan for new markets, check entry opportunities
- Every 15 minutes: Update position prices and P/L
- Every 5 minutes: Fetch latest tweet counts from xTracker
- Every hour: Check for resolved markets, claim winnings
- Daily: Update daily stats, recalculate rolling averages

**Implementation:**
```python
class ElonBot:
    def __init__(self)
    
    async def initialize(self) -> None
    async def run_scan_cycle(self) -> None
    async def run_price_update(self) -> None
    async def run_tweet_count_update(self) -> None
    async def run_resolution_check(self) -> None
    async def run_daily_stats(self) -> None
    async def start(self) -> None
    async def stop(self) -> None
```

---

## Configuration

### Environment Variables (`.env`)

```bash
# Polymarket API (get from user's sportsbot)
POLYMARKET_API_KEY=
POLYMARKET_API_SECRET=
POLYMARKET_PASSPHRASE=

# Optional: Notifications
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=

# Dashboard
DASHBOARD_PORT=5025
```

### Default Settings (`config/settings.py`)

```python
DEFAULT_SETTINGS = {
    "bot_enabled": True,
    "max_exposure": 200.0,
    "bet_size_per_bucket": 10.0,
    "play_weekly_markets": True,
    "play_short_term_markets": True,
    "max_entry_price_weekly": 0.10,
    "max_entry_price_short": 0.12,
    "entry_window_weekly": 36,  # hours
    "entry_window_short": 12,   # hours
    "min_buckets_to_enter": 5,
    "max_buckets_per_market": 10,
    "early_exit_threshold": 0.50,
    "scan_interval_minutes": 30,
}

# Historical baseline for cold start
HISTORICAL_BASELINE = {
    "weekly_mean": 550,
    "weekly_std": 100,
    "daily_mean": 78,
    "min_expected_weekly": 350,
    "max_expected_weekly": 800,
}
```

---

## Build Order

Build each component fully and test before moving to the next:

### Phase 1: Foundation
1. **`requirements.txt`** - All dependencies
2. **`db/database.py`** - SQLite connection, initialization
3. **`db/models.py`** - Schema creation
4. **`config/settings.py`** - Default settings, env loading

### Phase 2: Data Layer
5. **`core/xtracker_client.py`** - xTracker API integration
6. **`core/market_scanner.py`** - Polymarket market discovery

### Phase 3: Intelligence
7. **`core/projection_engine.py`** - Adaptive learning & projections
8. **`core/portfolio_manager.py`** - Risk management
9. **`core/entry_manager.py`** - Entry decision logic
10. **`core/position_manager.py`** - Position tracking

### Phase 4: Polymarket Integration
11. **`polymarket/client.py`** - API wrapper (needs user's credentials)
12. **`polymarket/orders.py`** - Order execution
13. **`polymarket/claims.py`** - Claiming winnings

### Phase 5: Dashboard
14. **`dashboard/app.py`** - FastAPI server
15. **`dashboard/routes/api.py`** - API endpoints
16. **`dashboard/routes/controls.py`** - Settings endpoints
17. **`dashboard/templates/index.html`** - Dashboard UI
18. **`dashboard/static/style.css`** - Styling
19. **`dashboard/static/app.js`** - Frontend JavaScript

### Phase 6: Orchestration
20. **`scheduler.py`** - APScheduler setup
21. **`bot.py`** - Main bot orchestrator
22. **`README.md`** - Documentation

---

## Testing Commands

After building each component, test with:

```bash
# Test database
python -c "from db.database import Database; db = Database(); db.initialize()"

# Test xTracker
python -c "import asyncio; from core.xtracker_client import XTrackerClient; print(asyncio.run(XTrackerClient().get_active_trackings()))"

# Test market scanner
python -c "import asyncio; from core.market_scanner import MarketScanner; ..."

# Run dashboard only
uvicorn dashboard.app:app --host 0.0.0.0 --port 5025 --reload

# Run full bot
python bot.py
```

---

## Important Notes

1. **Polymarket API:** The user has existing code in `/sportsbot` that handles Polymarket authentication and order execution. Adapt that code for this project.

2. **xTracker is the source of truth:** Always use xTracker for tweet counts, not Twitter API directly. This ensures our counts match Polymarket's resolution.

3. **Error handling:** All API calls should have proper error handling, retries, and logging.

4. **Rate limiting:** xTracker and Polymarket have rate limits. Implement exponential backoff.

5. **Logging:** Log all significant actions (entries, exits, errors) to both file and activity_log table.

6. **Dashboard security:** For now, no authentication. In production, add basic auth.

7. **Timezone:** All times should be in UTC internally, convert to ET for display (Polymarket uses ET for market times).

---

## Success Criteria

The bot is complete when:

1. ✅ Dashboard accessible at `http://localhost:5025`
2. ✅ Bot automatically scans for new markets every 30 minutes
3. ✅ Bot enters markets that meet criteria (within entry window, cheap buckets, under exposure limit)
4. ✅ Positions display with real-time P/L updates
5. ✅ Resolved positions are automatically claimed
6. ✅ Settings adjustable via dashboard
7. ✅ Bot can be paused/resumed via dashboard
8. ✅ Activity log shows all bot actions
9. ✅ Performance stats track win rate and ROI over time

---

## Questions for User

Before starting Polymarket integration, need from user:
1. Polymarket API credentials (from sportsbot `.env`)
2. Polymarket client code (from sportsbot `polymarket/` directory)
3. Any specific order execution preferences (limit vs market orders, slippage tolerance)
