# ElonBot - Polymarket Tweet Count Trading Bot

An automated trading bot that monitors Elon Musk's tweet activity and trades on Polymarket's tweet count prediction markets.

## Strategy

This bot replicates the strategy used by successful traders like @Annica ($271K+ profit):

1. **Early Entry** - Enter markets within first 36 hours when bucket prices are cheap (3-10¢)
2. **Wide Spread** - Buy 6-10 buckets around the projected tweet count range
3. **Hold to Resolution** - Don't sell early; let winners pay for losers
4. **Adaptive Learning** - Improve projections based on actual results over time

## Features

- 🔍 **Multi-Market Scanning** - Finds all active Elon tweet markets (weekly + short-term)
- 📊 **Adaptive Projections** - Machine learning-based tweet count predictions
- 💰 **Automatic Entry** - Places orders when criteria are met
- 📈 **Position Tracking** - Real-time P/L monitoring
- 🎯 **Auto-Claim** - Claims winning positions after resolution
- 🖥️ **Web Dashboard** - Control everything from port 5025

## Setup

### 1. Clone and Install

```bash
cd /home/user
git clone <repo> elonbot
cd elonbot
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your Polymarket API credentials
```

### 3. Initialize Database

```bash
python -c "from db.database import Database; Database().initialize()"
```

### 4. Run the Bot

```bash
# Run full bot with scheduler
python bot.py

# Or run dashboard only (for testing)
uvicorn dashboard.app:app --host 0.0.0.0 --port 5025 --reload
```

## Dashboard

Access at `http://your-server:5025`

### Features:
- Portfolio overview (cash, deployed, P/L)
- Active markets with entry opportunities
- Position details per market
- Bot ON/OFF toggle
- Adjustable settings (max exposure, bet size)
- Activity log
- Performance statistics

## Configuration

Settings adjustable via dashboard:

| Setting | Default | Description |
|---------|---------|-------------|
| Max Exposure | $200 | Maximum total capital deployed |
| Bet Size | $10 | Amount per bucket position |
| Weekly Markets | ON | Trade 7-day markets |
| Short-term Markets | ON | Trade 2-3 day markets |
| Max Entry Price (Weekly) | 10¢ | Don't buy buckets above this |
| Max Entry Price (Short) | 12¢ | Don't buy buckets above this |
| Entry Window (Weekly) | 36h | Enter within X hours of market open |
| Entry Window (Short) | 12h | Enter within X hours of market open |

## Architecture

```
elonbot/
├── bot.py              # Main orchestrator
├── scheduler.py        # Scheduled tasks
├── config/             # Configuration
├── core/               # Business logic
│   ├── market_scanner.py
│   ├── xtracker_client.py
│   ├── projection_engine.py
│   ├── entry_manager.py
│   ├── position_manager.py
│   └── portfolio_manager.py
├── polymarket/         # Polymarket API integration
├── db/                 # Database layer
├── dashboard/          # Web UI
└── data/               # SQLite database
```

## Data Sources

- **xTracker API** (`xtracker.polymarket.com`) - Official tweet counter used for market resolution
- **Polymarket API** - Market data and order execution

## Risk Warning

This bot trades real money. Start with small amounts ($10/bucket, $200 max) until you verify it works correctly. Past performance does not guarantee future results.

## License

Private - Not for distribution
