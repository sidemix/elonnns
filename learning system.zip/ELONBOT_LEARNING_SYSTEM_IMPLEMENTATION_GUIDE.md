# ElonBot Learning System Implementation Guide

## Context for Claude

You are helping Tyler implement a learning system for ElonBot, a Polymarket trading bot that trades on Elon Musk tweet count prediction markets. The bot currently works but has a critical flaw: when it enters markets before live xTracker data exists, it falls back to a wide hardcoded range (350-668 tweets) and buys extreme buckets that rarely win.

The goal is to make the bot **learn from historical outcomes** so its predictions get better over time.

## Current State

- Bot location: `/home/ubuntu/elonbot/`
- Database: SQLite at `/home/ubuntu/elonbot/data/elonbot.db`
- Key files:
  - `core/projection_engine.py` - Makes tweet count predictions
  - `core/entry_manager.py` - Decides when/what to buy
  - `bot.py` - Main scan cycle
  - `config/settings.py` - Configuration

The bot already:
- Fetches live tweet counts from xTracker API
- Stores markets and trades in SQLite
- Has a projection engine (but it uses hardcoded fallbacks)

## What We Need to Build

### Phase 1: Data Collection (Start Here)

**1.1 Add new database tables**

Run these SQL migrations:

```sql
-- Historical tweet counts (one row per completed market)
CREATE TABLE IF NOT EXISTS tweet_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT UNIQUE NOT NULL,
    market_type TEXT NOT NULL,  -- 'weekly' or 'short'
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    duration_hours REAL NOT NULL,
    final_count INTEGER NOT NULL,
    winning_bucket TEXT NOT NULL,
    tweets_per_day REAL NOT NULL,
    tweets_per_hour REAL NOT NULL,
    week_of_year INTEGER,
    day_of_week_start INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Daily tweet counts for granular pattern analysis
CREATE TABLE IF NOT EXISTS daily_tweet_counts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    date DATE NOT NULL,
    day_number INTEGER NOT NULL,
    tweet_count INTEGER NOT NULL,
    cumulative_count INTEGER NOT NULL,
    day_of_week INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(market_id, date)
);

-- Prediction tracking for calibration
CREATE TABLE IF NOT EXISTS prediction_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    prediction_time DATETIME NOT NULL,
    hours_into_market REAL NOT NULL,
    predicted_center INTEGER NOT NULL,
    predicted_low INTEGER NOT NULL,
    predicted_high INTEGER NOT NULL,
    confidence TEXT NOT NULL,
    confidence_score REAL NOT NULL,
    actual_final INTEGER,
    prediction_error INTEGER,
    within_range BOOLEAN,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tweet_history_type ON tweet_history(market_type);
CREATE INDEX IF NOT EXISTS idx_tweet_history_date ON tweet_history(start_date);
CREATE INDEX IF NOT EXISTS idx_daily_counts_market ON daily_tweet_counts(market_id);
CREATE INDEX IF NOT EXISTS idx_predictions_market ON prediction_outcomes(market_id);
```

**1.2 Create data collector module**

Create `core/learning/data_collector.py`:

```python
"""
Data collector for the learning system.
Records market outcomes, daily snapshots, and predictions for learning.
"""

import structlog
from datetime import datetime, UTC
from typing import Optional

log = structlog.get_logger()


class DataCollector:
    def __init__(self, db):
        self.db = db
    
    async def record_market_outcome(
        self, 
        market_id: str,
        market_type: str,
        start_date: datetime,
        end_date: datetime,
        final_count: int,
        winning_bucket: str
    ) -> None:
        """Record a completed market's outcome for learning."""
        
        duration_hours = (end_date - start_date).total_seconds() / 3600
        tweets_per_day = final_count / (duration_hours / 24)
        tweets_per_hour = final_count / duration_hours
        
        try:
            await self.db.execute("""
                INSERT OR REPLACE INTO tweet_history 
                (market_id, market_type, start_date, end_date, duration_hours,
                 final_count, winning_bucket, tweets_per_day, tweets_per_hour,
                 week_of_year, day_of_week_start)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                market_id,
                market_type,
                start_date.isoformat(),
                end_date.isoformat(),
                duration_hours,
                final_count,
                winning_bucket,
                tweets_per_day,
                tweets_per_hour,
                start_date.isocalendar()[1],
                start_date.weekday()
            ))
            
            log.info("market_outcome_recorded", 
                market_id=market_id, 
                final_count=final_count,
                winning_bucket=winning_bucket)
                
        except Exception as e:
            log.error("failed_to_record_outcome", error=str(e), market_id=market_id)
    
    async def record_daily_snapshot(
        self,
        market_id: str,
        date: datetime,
        day_number: int,
        daily_tweets: int,
        cumulative_count: int
    ) -> None:
        """Record daily tweet count snapshot."""
        
        try:
            await self.db.execute("""
                INSERT OR REPLACE INTO daily_tweet_counts
                (market_id, date, day_number, tweet_count, cumulative_count, day_of_week)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                market_id,
                date.date().isoformat(),
                day_number,
                daily_tweets,
                cumulative_count,
                date.weekday()
            ))
            
            log.debug("daily_snapshot_recorded", market_id=market_id, day=day_number, count=cumulative_count)
            
        except Exception as e:
            log.error("failed_to_record_snapshot", error=str(e))
    
    async def record_prediction(
        self,
        market_id: str,
        hours_into_market: float,
        predicted_center: int,
        predicted_low: int,
        predicted_high: int,
        confidence: str,
        confidence_score: float
    ) -> None:
        """Record a prediction for later accuracy analysis."""
        
        try:
            await self.db.execute("""
                INSERT INTO prediction_outcomes
                (market_id, prediction_time, hours_into_market,
                 predicted_center, predicted_low, predicted_high, 
                 confidence, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                market_id,
                datetime.now(UTC).isoformat(),
                hours_into_market,
                predicted_center,
                predicted_low,
                predicted_high,
                confidence,
                confidence_score
            ))
            
        except Exception as e:
            log.error("failed_to_record_prediction", error=str(e))
    
    async def update_prediction_outcomes(
        self,
        market_id: str,
        actual_final: int
    ) -> None:
        """Update predictions with actual outcome for accuracy tracking."""
        
        try:
            await self.db.execute("""
                UPDATE prediction_outcomes
                SET actual_final = ?,
                    prediction_error = ? - predicted_center,
                    within_range = (? >= predicted_low AND ? <= predicted_high)
                WHERE market_id = ? AND actual_final IS NULL
            """, (actual_final, actual_final, actual_final, actual_final, market_id))
            
            log.info("prediction_outcomes_updated", market_id=market_id, actual=actual_final)
            
        except Exception as e:
            log.error("failed_to_update_predictions", error=str(e))
```

**1.3 Integrate data collection into resolution handler**

Find where the bot handles market resolution (likely in `core/resolution_checker.py` or similar) and add:

```python
# After determining winning bucket and final count
await data_collector.record_market_outcome(
    market_id=market.id,
    market_type=market.duration_type,
    start_date=market.start_date,
    end_date=market.end_date,
    final_count=final_count,  # Extract from winning bucket midpoint or xTracker
    winning_bucket=winning_outcome
)

# Update any predictions we made for this market
await data_collector.update_prediction_outcomes(
    market_id=market.id,
    actual_final=final_count
)
```

---

### Phase 2: Statistics Calculator

Create `core/learning/stats_calculator.py`:

```python
"""
Calculates statistics from historical tweet data for smarter projections.
"""

import statistics
from dataclasses import dataclass
from typing import Optional, List
import structlog

log = structlog.get_logger()


@dataclass
class HistoricalStats:
    """Statistics derived from historical tweet data."""
    sample_size: int
    mean: float
    median: float
    std_dev: float
    min_count: int
    max_count: int
    p10: float  # 10th percentile
    p25: float  # 25th percentile
    p75: float  # 75th percentile
    p90: float  # 90th percentile
    recent_mean: Optional[float]  # Last 4 data points
    trend_direction: str  # 'increasing', 'decreasing', 'stable'


class StatsCalculator:
    def __init__(self, db):
        self.db = db
    
    async def get_weekly_stats(self, min_samples: int = 3) -> Optional[HistoricalStats]:
        """Calculate statistics for weekly markets."""
        
        rows = await self.db.fetch_all("""
            SELECT final_count
            FROM tweet_history
            WHERE market_type = 'weekly'
            AND duration_hours BETWEEN 160 AND 175
            ORDER BY start_date DESC
        """)
        
        if len(rows) < min_samples:
            log.info("insufficient_weekly_data", sample_size=len(rows), required=min_samples)
            return None
        
        counts = [r[0] for r in rows]
        return self._build_stats(counts)
    
    async def get_short_stats(self, duration_hours: int, min_samples: int = 3) -> Optional[HistoricalStats]:
        """Calculate statistics for short-term markets of similar duration."""
        
        min_hours = duration_hours * 0.85
        max_hours = duration_hours * 1.15
        
        rows = await self.db.fetch_all("""
            SELECT final_count
            FROM tweet_history
            WHERE market_type = 'short'
            AND duration_hours BETWEEN ? AND ?
            ORDER BY start_date DESC
        """, (min_hours, max_hours))
        
        if len(rows) < min_samples:
            # Try to extrapolate from hourly rates
            return await self._extrapolate_from_hourly_rate(duration_hours)
        
        counts = [r[0] for r in rows]
        return self._build_stats(counts)
    
    async def _extrapolate_from_hourly_rate(self, target_hours: int) -> Optional[HistoricalStats]:
        """Extrapolate stats from tweets_per_hour when exact duration matches are scarce."""
        
        rows = await self.db.fetch_all("""
            SELECT tweets_per_hour
            FROM tweet_history
            ORDER BY start_date DESC
            LIMIT 20
        """)
        
        if len(rows) < 3:
            return None
        
        hourly_rates = [r[0] for r in rows]
        avg_rate = statistics.mean(hourly_rates)
        rate_stddev = statistics.stdev(hourly_rates) if len(hourly_rates) > 1 else avg_rate * 0.2
        
        projected_mean = avg_rate * target_hours
        projected_stddev = rate_stddev * target_hours
        
        return HistoricalStats(
            sample_size=len(rows),
            mean=projected_mean,
            median=projected_mean,
            std_dev=projected_stddev,
            min_count=int(projected_mean - 2 * projected_stddev),
            max_count=int(projected_mean + 2 * projected_stddev),
            p10=projected_mean - 1.3 * projected_stddev,
            p25=projected_mean - 0.67 * projected_stddev,
            p75=projected_mean + 0.67 * projected_stddev,
            p90=projected_mean + 1.3 * projected_stddev,
            recent_mean=None,
            trend_direction='stable'
        )
    
    async def get_day_of_week_multipliers(self) -> dict:
        """Get average tweets by day of week as multipliers."""
        
        rows = await self.db.fetch_all("""
            SELECT day_of_week, AVG(tweet_count) as avg_tweets
            FROM daily_tweet_counts
            GROUP BY day_of_week
            HAVING COUNT(*) >= 2
        """)
        
        if not rows:
            return {}
        
        day_avgs = {r[0]: r[1] for r in rows}
        overall_avg = statistics.mean(day_avgs.values())
        
        # Return as multipliers (1.0 = average, 1.2 = 20% above average)
        return {day: avg / overall_avg for day, avg in day_avgs.items()}
    
    def _build_stats(self, counts: List[int]) -> HistoricalStats:
        """Build HistoricalStats from a list of counts."""
        
        sorted_counts = sorted(counts)
        recent = counts[:4] if len(counts) >= 4 else counts
        
        return HistoricalStats(
            sample_size=len(counts),
            mean=statistics.mean(counts),
            median=statistics.median(counts),
            std_dev=statistics.stdev(counts) if len(counts) > 1 else 0,
            min_count=min(counts),
            max_count=max(counts),
            p10=self._percentile(sorted_counts, 10),
            p25=self._percentile(sorted_counts, 25),
            p75=self._percentile(sorted_counts, 75),
            p90=self._percentile(sorted_counts, 90),
            recent_mean=statistics.mean(recent),
            trend_direction=self._detect_trend(counts)
        )
    
    def _percentile(self, sorted_data: List[int], p: int) -> float:
        """Calculate percentile from sorted data."""
        if len(sorted_data) == 1:
            return sorted_data[0]
        
        k = (len(sorted_data) - 1) * p / 100
        f = int(k)
        c = min(f + 1, len(sorted_data) - 1)
        return sorted_data[f] + (sorted_data[c] - sorted_data[f]) * (k - f)
    
    def _detect_trend(self, counts: List[int]) -> str:
        """Detect trend direction from most recent to oldest."""
        if len(counts) < 4:
            return 'stable'
        
        recent = statistics.mean(counts[:4])
        older = statistics.mean(counts[4:8]) if len(counts) >= 8 else statistics.mean(counts[4:])
        
        if older == 0:
            return 'stable'
        
        change_pct = (recent - older) / older * 100
        
        if change_pct > 15:
            return 'increasing'
        elif change_pct < -15:
            return 'decreasing'
        return 'stable'
```

---

### Phase 3: Smart Projection Engine

Create `core/learning/smart_projection.py`:

```python
"""
Smart projection engine that learns from historical data.
Replaces the hardcoded fallback ranges with learned distributions.
"""

from dataclasses import dataclass
from datetime import datetime, UTC
from typing import Optional
import structlog

from .stats_calculator import StatsCalculator, HistoricalStats

log = structlog.get_logger()


@dataclass
class SmartProjection:
    """A projection with confidence intervals based on learned data."""
    center: int
    low: int
    high: int
    confidence: str  # 'high', 'medium', 'low'
    confidence_score: float  # 0.0 to 1.0
    method: str  # 'live_pace', 'historical_learned', 'historical_fallback'
    sample_size: int
    reasoning: str


class SmartProjectionEngine:
    """
    Projection engine that uses learned historical data.
    
    Priority order:
    1. Live pace from xTracker (best)
    2. Learned historical distribution (good)
    3. Hardcoded fallback (last resort)
    """
    
    # Fallback values - only used when NO learned data exists
    FALLBACK_WEEKLY_CENTER = 480
    FALLBACK_WEEKLY_STDDEV = 120
    FALLBACK_SHORT_PER_HOUR = 2.8
    
    def __init__(self, db, stats_calculator: StatsCalculator, xtracker_client):
        self.db = db
        self.stats = stats_calculator
        self.xtracker = xtracker_client
    
    async def project(self, market) -> SmartProjection:
        """Generate the best possible projection for a market."""
        
        now = datetime.now(UTC)
        market_started = now >= market.start_date
        duration_hours = (market.end_date - market.start_date).total_seconds() / 3600
        
        # Method 1: Live pace (when market has started and we have data)
        if market_started:
            live_data = await self._get_live_data(market)
            if live_data and live_data.get('count', 0) > 0:
                return await self._project_from_live_pace(market, live_data, duration_hours)
        
        # Method 2: Learned historical (when we have past data)
        stats = await self._get_relevant_stats(market, duration_hours)
        if stats and stats.sample_size >= 3:
            return self._project_from_learned_history(market, stats)
        
        # Method 3: Fallback (no data yet - be conservative)
        return self._project_from_fallback(market, duration_hours, stats)
    
    async def _get_live_data(self, market) -> Optional[dict]:
        """Fetch live tweet count from xTracker."""
        try:
            data = await self.xtracker.get_tweet_count(market.start_date, market.end_date)
            return data
        except Exception as e:
            log.warning("xtracker_fetch_failed", error=str(e))
            return None
    
    async def _get_relevant_stats(self, market, duration_hours: float) -> Optional[HistoricalStats]:
        """Get historical stats relevant to this market type."""
        
        if market.duration_type == 'weekly':
            return await self.stats.get_weekly_stats()
        else:
            return await self.stats.get_short_stats(int(duration_hours))
    
    async def _project_from_live_pace(
        self, 
        market, 
        live_data: dict,
        total_hours: float
    ) -> SmartProjection:
        """Project using current tweet pace + historical variance."""
        
        now = datetime.now(UTC)
        elapsed_hours = (now - market.start_date).total_seconds() / 3600
        pct_complete = elapsed_hours / total_hours
        
        current_count = live_data['count']
        pace_per_hour = current_count / elapsed_hours if elapsed_hours > 0 else 0
        projected_final = int(pace_per_hour * total_hours)
        
        # Get historical stats to inform variance
        stats = await self._get_relevant_stats(market, total_hours)
        
        if stats and stats.sample_size >= 3:
            # Narrow variance as we get more complete
            variance_factor = max(0.3, 1.0 - (pct_complete * 0.7))
            adjusted_stddev = stats.std_dev * variance_factor
            
            confidence_score = min(0.95, 0.5 + pct_complete * 0.5)
            
            return SmartProjection(
                center=projected_final,
                low=int(projected_final - 1.3 * adjusted_stddev),
                high=int(projected_final + 1.3 * adjusted_stddev),
                confidence='high' if pct_complete > 0.5 else 'medium',
                confidence_score=confidence_score,
                method='live_pace',
                sample_size=stats.sample_size,
                reasoning=f"Live: {current_count} tweets, {pace_per_hour:.1f}/hr, {pct_complete*100:.0f}% complete. "
                         f"Variance from {stats.sample_size} historical markets."
            )
        else:
            # No historical data - use percentage-based interval
            interval = max(30, projected_final * 0.15 * (1 - pct_complete))
            
            return SmartProjection(
                center=projected_final,
                low=int(projected_final - interval),
                high=int(projected_final + interval),
                confidence='medium' if pct_complete > 0.3 else 'low',
                confidence_score=0.4 + pct_complete * 0.4,
                method='live_pace',
                sample_size=0,
                reasoning=f"Live: {current_count} tweets, {pace_per_hour:.1f}/hr. No historical data for variance."
            )
    
    def _project_from_learned_history(
        self, 
        market,
        stats: HistoricalStats
    ) -> SmartProjection:
        """Project using learned historical patterns (no live data yet)."""
        
        # Use recent mean if we detect a trend
        if stats.trend_direction in ('increasing', 'decreasing') and stats.recent_mean:
            center = int(stats.recent_mean)
        else:
            center = int(stats.mean)
        
        # Confidence based on sample size
        confidence_score = min(0.75, 0.35 + stats.sample_size * 0.04)
        
        return SmartProjection(
            center=center,
            low=int(stats.p10),
            high=int(stats.p90),
            confidence='medium' if stats.sample_size >= 8 else 'low',
            confidence_score=confidence_score,
            method='historical_learned',
            sample_size=stats.sample_size,
            reasoning=f"Learned from {stats.sample_size} markets. "
                     f"Mean: {stats.mean:.0f}, StdDev: {stats.std_dev:.0f}, Trend: {stats.trend_direction}."
        )
    
    def _project_from_fallback(
        self, 
        market,
        duration_hours: float,
        partial_stats: Optional[HistoricalStats]
    ) -> SmartProjection:
        """Fallback when insufficient data exists. BE CONSERVATIVE."""
        
        if partial_stats and partial_stats.sample_size > 0:
            center = int(partial_stats.mean)
            stddev = partial_stats.std_dev if partial_stats.std_dev > 0 else self.FALLBACK_WEEKLY_STDDEV
            sample_size = partial_stats.sample_size
            reasoning = f"Limited data: only {sample_size} markets. Using conservative interval."
        elif market.duration_type == 'weekly':
            center = self.FALLBACK_WEEKLY_CENTER
            stddev = self.FALLBACK_WEEKLY_STDDEV
            sample_size = 0
            reasoning = "No historical data. Using default weekly estimates. SHOULD WAIT FOR DATA."
        else:
            center = int(self.FALLBACK_SHORT_PER_HOUR * duration_hours)
            stddev = center * 0.25
            sample_size = 0
            reasoning = "No historical data for short markets. Using hourly rate estimate."
        
        return SmartProjection(
            center=center,
            low=int(center - 2 * stddev),
            high=int(center + 2 * stddev),
            confidence='low',
            confidence_score=0.2 if sample_size == 0 else 0.3,
            method='historical_fallback',
            sample_size=sample_size,
            reasoning=reasoning
        )
```

---

### Phase 4: Entry Advisor (Confidence-Based Decisions)

Create `core/learning/entry_advisor.py`:

```python
"""
Entry advisor that uses projection confidence to make smarter entry decisions.
"""

from dataclasses import dataclass
from typing import List, Dict, Any
import structlog

from .smart_projection import SmartProjection

log = structlog.get_logger()


@dataclass
class EntryAdvice:
    """Advice on whether and how to enter a market."""
    should_enter: bool
    reason: str
    recommended_buckets: List[Dict[str, Any]]
    position_size_multiplier: float  # 1.0 = full size, 0.5 = half, etc.
    confidence_score: float


class EntryAdvisor:
    """
    Decides whether to enter markets based on projection confidence.
    
    Key principle: Don't enter with low confidence. Wait for better data.
    """
    
    # Confidence thresholds
    MIN_CONFIDENCE_TO_ENTER = 0.35  # Below this, don't enter at all
    FULL_SIZE_CONFIDENCE = 0.70    # Above this, use full position size
    MEDIUM_SIZE_CONFIDENCE = 0.50  # Above this, use 70% position size
    
    def __init__(self, settings: dict):
        self.settings = settings
    
    def advise(
        self, 
        market, 
        projection: SmartProjection, 
        bucket_prices: Dict[str, Dict]
    ) -> EntryAdvice:
        """Generate entry advice for a market."""
        
        # Rule 1: Check minimum confidence
        if projection.confidence_score < self.MIN_CONFIDENCE_TO_ENTER:
            return EntryAdvice(
                should_enter=False,
                reason=f"Confidence too low ({projection.confidence_score:.0%}). "
                       f"Method: {projection.method}. {projection.reasoning}",
                recommended_buckets=[],
                position_size_multiplier=0,
                confidence_score=projection.confidence_score
            )
        
        # Rule 2: Don't enter on pure fallback (no learned data)
        if projection.method == 'historical_fallback' and projection.sample_size == 0:
            return EntryAdvice(
                should_enter=False,
                reason=f"No historical data to inform prediction. Waiting for learned data. "
                       f"{projection.reasoning}",
                recommended_buckets=[],
                position_size_multiplier=0,
                confidence_score=projection.confidence_score
            )
        
        # Rule 3: Select buckets
        selected = self._select_buckets(market, projection, bucket_prices)
        
        if not selected:
            return EntryAdvice(
                should_enter=False,
                reason="No buckets available within projection range at acceptable prices.",
                recommended_buckets=[],
                position_size_multiplier=0,
                confidence_score=projection.confidence_score
            )
        
        # Rule 4: Determine position size based on confidence
        if projection.confidence_score >= self.FULL_SIZE_CONFIDENCE:
            size_mult = 1.0
        elif projection.confidence_score >= self.MEDIUM_SIZE_CONFIDENCE:
            size_mult = 0.7
        else:
            size_mult = 0.5
        
        return EntryAdvice(
            should_enter=True,
            reason=f"Entering with {projection.confidence} confidence ({projection.confidence_score:.0%}). "
                   f"{projection.reasoning}",
            recommended_buckets=selected,
            position_size_multiplier=size_mult,
            confidence_score=projection.confidence_score
        )
    
    def _select_buckets(
        self, 
        market,
        projection: SmartProjection, 
        bucket_prices: Dict[str, Dict]
    ) -> List[Dict[str, Any]]:
        """Select buckets within projection range under max price."""
        
        # Get settings
        if market.duration_type == 'weekly':
            max_price = self.settings.get('max_entry_price_weekly', 0.10)
        else:
            max_price = self.settings.get('max_entry_price_short', 0.12)
        
        max_buckets = self.settings.get('max_buckets_per_market', 10)
        
        # Tighter buffer for higher confidence
        if projection.confidence_score >= 0.7:
            buffer = 15
        elif projection.confidence_score >= 0.5:
            buffer = 25
        else:
            buffer = 35
        
        range_low = projection.low - buffer
        range_high = projection.high + buffer
        
        log.info("bucket_selection", 
            projection_center=projection.center,
            projection_range=f"{projection.low}-{projection.high}",
            selection_range=f"{range_low}-{range_high}",
            max_price=max_price,
            confidence=projection.confidence_score
        )
        
        candidates = []
        for bucket_range, data in bucket_prices.items():
            midpoint = self._get_bucket_midpoint(bucket_range)
            price = data.get('yes_price', 1.0)
            
            # Check if in range and under price
            if not (range_low <= midpoint <= range_high):
                continue
            if price > max_price:
                continue
            
            distance_from_center = abs(midpoint - projection.center)
            
            # Priority score: favor cheap buckets close to center
            # Higher score = better candidate
            value_score = (1 - price) / max(price, 0.01)
            distance_penalty = distance_from_center / 100
            priority = value_score - distance_penalty
            
            candidates.append({
                'bucket': bucket_range,
                'price': price,
                'midpoint': midpoint,
                'distance_from_center': distance_from_center,
                'priority_score': priority
            })
        
        # Sort by priority, take top N
        candidates.sort(key=lambda x: x['priority_score'], reverse=True)
        selected = candidates[:max_buckets]
        
        log.info("buckets_selected",
            total_candidates=len(candidates),
            selected_count=len(selected),
            selected_buckets=[b['bucket'] for b in selected]
        )
        
        return selected
    
    def _get_bucket_midpoint(self, bucket_range: str) -> int:
        """Extract midpoint from bucket range string like '480-499'."""
        try:
            low, high = map(int, bucket_range.split('-'))
            return (low + high) // 2
        except:
            return 0
```

---

### Phase 5: Integration

**5.1 Update bot.py scan cycle**

Modify the scan cycle to use the new learning components:

```python
# In bot.py - add imports
from core.learning.data_collector import DataCollector
from core.learning.stats_calculator import StatsCalculator
from core.learning.smart_projection import SmartProjectionEngine
from core.learning.entry_advisor import EntryAdvisor

# In __init__ or initialize()
self.data_collector = DataCollector(self.db)
self.stats_calculator = StatsCalculator(self.db)
self.smart_projection = SmartProjectionEngine(self.db, self.stats_calculator, self.xtracker)
self.entry_advisor = EntryAdvisor(self.settings)

# In run_scan_cycle() - replace old projection logic with:
async def evaluate_market_for_entry(self, market):
    """Evaluate a market using the learning system."""
    
    # Get smart projection
    projection = await self.smart_projection.project(market)
    
    # Log prediction for future learning
    hours_into = max(0, (datetime.now(UTC) - market.start_date).total_seconds() / 3600)
    await self.data_collector.record_prediction(
        market_id=market.id,
        hours_into_market=hours_into,
        predicted_center=projection.center,
        predicted_low=projection.low,
        predicted_high=projection.high,
        confidence=projection.confidence,
        confidence_score=projection.confidence_score
    )
    
    # Get bucket prices
    bucket_prices = await self.get_bucket_prices(market)
    
    # Get entry advice
    advice = self.entry_advisor.advise(market, projection, bucket_prices)
    
    if not advice.should_enter:
        log.info("entry_skipped",
            market=market.id,
            reason=advice.reason,
            confidence=advice.confidence_score,
            method=projection.method
        )
        return None
    
    log.info("entry_approved",
        market=market.id,
        buckets=[b['bucket'] for b in advice.recommended_buckets],
        size_multiplier=advice.position_size_multiplier,
        confidence=advice.confidence_score
    )
    
    return advice
```

**5.2 Update resolution handler**

When a market resolves, record the outcome:

```python
# In resolution_checker.py or wherever resolution is handled

async def handle_market_resolution(self, market, winning_outcome: str):
    """Handle a resolved market."""
    
    # Extract final count from winning bucket
    final_count = self._estimate_final_count(winning_outcome)
    
    # Record for learning
    await self.data_collector.record_market_outcome(
        market_id=market.id,
        market_type=market.duration_type,
        start_date=market.start_date,
        end_date=market.end_date,
        final_count=final_count,
        winning_bucket=winning_outcome
    )
    
    # Update prediction accuracy
    await self.data_collector.update_prediction_outcomes(
        market_id=market.id,
        actual_final=final_count
    )
    
    # Continue with existing resolution logic (claiming winnings, etc.)
    ...

def _estimate_final_count(self, winning_bucket: str) -> int:
    """Estimate final count from winning bucket (use midpoint)."""
    try:
        low, high = map(int, winning_bucket.split('-'))
        return (low + high) // 2
    except:
        return 0
```

---

### Phase 6: Backfill Historical Data (Optional but Recommended)

Create `scripts/backfill_history.py` to seed the database with past market data:

```python
"""
Backfill historical market outcomes to bootstrap the learning system.
Run once after deploying the learning system.
"""

import asyncio
from datetime import datetime
from core.learning.data_collector import DataCollector
# Import your database and API clients

async def backfill():
    """Fetch resolved markets and record their outcomes."""
    
    # This depends on your Polymarket API access
    # Fetch resolved Elon tweet markets
    resolved_markets = await fetch_resolved_elon_markets(limit=50)
    
    for market in resolved_markets:
        winning_bucket = market.winning_outcome  # e.g., "480-499"
        low, high = map(int, winning_bucket.split('-'))
        estimated_final = (low + high) // 2
        
        await data_collector.record_market_outcome(
            market_id=market.id,
            market_type='weekly' if market.duration_hours > 100 else 'short',
            start_date=market.start_date,
            end_date=market.end_date,
            final_count=estimated_final,
            winning_bucket=winning_bucket
        )
        
        print(f"Backfilled: {market.question} -> {winning_bucket} (~{estimated_final})")

if __name__ == "__main__":
    asyncio.run(backfill())
```

---

## Testing the Implementation

After implementing, verify with these checks:

```bash
# 1. Check tables exist
sqlite3 /home/ubuntu/elonbot/data/elonbot.db ".tables"
# Should show: tweet_history, daily_tweet_counts, prediction_outcomes

# 2. Check data is being collected (after a market resolves)
sqlite3 /home/ubuntu/elonbot/data/elonbot.db "SELECT * FROM tweet_history;"

# 3. Check predictions are being logged
sqlite3 /home/ubuntu/elonbot/data/elonbot.db "SELECT * FROM prediction_outcomes ORDER BY created_at DESC LIMIT 5;"

# 4. Check logs for learning system activity
grep -E "(confidence|learned|historical_learned|entry_skipped|entry_approved)" /home/ubuntu/elonbot/logs/bot.log | tail -20
```

---

## Expected Behavior Changes

| Scenario | Old Bot | New Bot |
|----------|---------|---------|
| Market before tracking starts, no history | Enters with 350-668 range, buys extremes | SKIPS - "No historical data" |
| Market before tracking, 5+ weeks of history | Enters with 350-668 range | Enters with learned range (e.g., 420-540) |
| Market with live data | Projects from pace | Projects from pace + learned variance |
| Low confidence situation | Enters anyway | Skips or uses reduced position size |

---

## Dashboard Updates (Optional)

Add a learning stats endpoint to show the bot's knowledge:

```python
@router.get("/api/learning/stats")
async def get_learning_stats():
    weekly_stats = await stats_calculator.get_weekly_stats()
    
    return {
        "weekly": {
            "sample_size": weekly_stats.sample_size if weekly_stats else 0,
            "mean": weekly_stats.mean if weekly_stats else None,
            "std_dev": weekly_stats.std_dev if weekly_stats else None,
            "trend": weekly_stats.trend_direction if weekly_stats else None,
            "range_p10_p90": f"{weekly_stats.p10:.0f}-{weekly_stats.p90:.0f}" if weekly_stats else None
        },
        "ready_for_trading": weekly_stats is not None and weekly_stats.sample_size >= 5
    }
```

---

## Summary

The implementation order is:

1. **Run SQL migrations** to create tables
2. **Create `core/learning/` directory** with the four modules
3. **Integrate DataCollector** into resolution handler
4. **Integrate SmartProjection + EntryAdvisor** into scan cycle
5. **Optional: Run backfill script** to seed historical data
6. **Test** by checking logs and database

The bot will start cautious (skipping entries when uncertain) and get progressively smarter as it accumulates market outcomes. After ~6-8 weeks of data, it should make noticeably better predictions.
