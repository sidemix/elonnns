# ElonBot Learning System Design

## Overview

This document outlines a learning system that allows ElonBot to build intelligence from historical tweet data, improving its predictions over time rather than relying on static fallback ranges.

---

## 1. Database Schema

### New Tables

```sql
-- Historical tweet counts (one row per completed market)
CREATE TABLE tweet_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT UNIQUE NOT NULL,
    market_type TEXT NOT NULL,  -- 'weekly' or 'short'
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    duration_hours INTEGER NOT NULL,
    final_count INTEGER NOT NULL,
    winning_bucket TEXT NOT NULL,
    
    -- Derived metrics (calculated on insert)
    tweets_per_day REAL NOT NULL,
    tweets_per_hour REAL NOT NULL,
    
    -- Context factors (for pattern detection)
    week_of_year INTEGER,
    day_of_week_start INTEGER,  -- 0=Monday, 6=Sunday
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Daily tweet counts within each market period (granular data)
CREATE TABLE daily_tweet_counts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    date DATE NOT NULL,
    day_number INTEGER NOT NULL,  -- Day 1, 2, 3... of the market
    tweet_count INTEGER NOT NULL,  -- Tweets on this specific day
    cumulative_count INTEGER NOT NULL,  -- Running total
    day_of_week INTEGER NOT NULL,  -- 0=Monday, 6=Sunday
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(market_id, date)
);

-- Prediction accuracy tracking (for calibration)
CREATE TABLE prediction_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    prediction_time DATETIME NOT NULL,
    hours_into_market REAL NOT NULL,
    
    -- What we predicted
    predicted_center INTEGER NOT NULL,
    predicted_low INTEGER NOT NULL,
    predicted_high INTEGER NOT NULL,
    confidence TEXT NOT NULL,
    
    -- What actually happened
    actual_final INTEGER,  -- NULL until market resolves
    prediction_error INTEGER,  -- actual - predicted_center
    within_range BOOLEAN,  -- Was actual within [low, high]?
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for fast queries
CREATE INDEX idx_tweet_history_type ON tweet_history(market_type);
CREATE INDEX idx_tweet_history_date ON tweet_history(start_date);
CREATE INDEX idx_daily_counts_market ON daily_tweet_counts(market_id);
CREATE INDEX idx_daily_counts_dow ON daily_tweet_counts(day_of_week);
CREATE INDEX idx_predictions_market ON prediction_outcomes(market_id);
```

---

## 2. Data Collection Logic

### 2.1 On Market Resolution

When a market ends and resolves, store the outcome:

```python
# core/learning/data_collector.py

async def record_market_outcome(self, market: Market, final_count: int, winning_bucket: str):
    """Record completed market data for learning."""
    
    duration_hours = (market.end_date - market.start_date).total_seconds() / 3600
    tweets_per_day = final_count / (duration_hours / 24)
    tweets_per_hour = final_count / duration_hours
    
    await self.db.execute("""
        INSERT OR REPLACE INTO tweet_history 
        (market_id, market_type, start_date, end_date, duration_hours,
         final_count, winning_bucket, tweets_per_day, tweets_per_hour,
         week_of_year, day_of_week_start)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        market.id,
        market.duration_type,
        market.start_date,
        market.end_date,
        duration_hours,
        final_count,
        winning_bucket,
        tweets_per_day,
        tweets_per_hour,
        market.start_date.isocalendar()[1],
        market.start_date.weekday()
    ))
```

### 2.2 Daily Snapshots

Capture daily tweet counts for granular pattern analysis:

```python
async def record_daily_snapshot(self, market: Market, current_count: int):
    """Record daily tweet count snapshot."""
    
    today = datetime.now(UTC).date()
    day_number = (today - market.start_date.date()).days + 1
    
    await self.db.execute("""
        INSERT OR REPLACE INTO daily_tweet_counts
        (market_id, date, day_number, tweet_count, cumulative_count, day_of_week)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        market.id,
        today,
        day_number,
        current_count - self._get_yesterday_count(market.id),  # Today's tweets
        current_count,  # Running total
        today.weekday()
    ))
```

### 2.3 Prediction Tracking

Record predictions for calibration:

```python
async def record_prediction(self, market: Market, projection: Projection):
    """Record a prediction for later accuracy analysis."""
    
    hours_into_market = (datetime.now(UTC) - market.start_date).total_seconds() / 3600
    
    await self.db.execute("""
        INSERT INTO prediction_outcomes
        (market_id, prediction_time, hours_into_market,
         predicted_center, predicted_low, predicted_high, confidence)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        market.id,
        datetime.now(UTC),
        hours_into_market,
        projection.center,
        projection.low,
        projection.high,
        projection.confidence
    ))
```

---

## 3. Learning-Based Projection Engine

### 3.1 Historical Statistics Calculator

```python
# core/learning/stats_calculator.py

from dataclasses import dataclass
from typing import Optional
import statistics

@dataclass
class HistoricalStats:
    """Statistics derived from historical tweet data."""
    sample_size: int
    mean: float
    median: float
    std_dev: float
    min_count: int
    max_count: int
    
    # Percentiles for confidence intervals
    p10: float  # 10th percentile
    p25: float  # 25th percentile  
    p75: float  # 75th percentile
    p90: float  # 90th percentile
    
    # Recent trend
    recent_mean: Optional[float]  # Last 4 weeks
    trend_direction: str  # 'increasing', 'decreasing', 'stable'


class StatsCalculator:
    def __init__(self, db):
        self.db = db
    
    async def get_weekly_stats(self, min_samples: int = 5) -> Optional[HistoricalStats]:
        """Calculate statistics for weekly markets."""
        
        rows = await self.db.fetch_all("""
            SELECT final_count, start_date
            FROM tweet_history
            WHERE market_type = 'weekly'
            AND duration_hours BETWEEN 164 AND 172  -- ~7 days
            ORDER BY start_date DESC
        """)
        
        if len(rows) < min_samples:
            return None
        
        counts = [r['final_count'] for r in rows]
        recent_counts = counts[:4]  # Last 4 weeks
        
        return HistoricalStats(
            sample_size=len(counts),
            mean=statistics.mean(counts),
            median=statistics.median(counts),
            std_dev=statistics.stdev(counts) if len(counts) > 1 else 0,
            min_count=min(counts),
            max_count=max(counts),
            p10=self._percentile(counts, 10),
            p25=self._percentile(counts, 25),
            p75=self._percentile(counts, 75),
            p90=self._percentile(counts, 90),
            recent_mean=statistics.mean(recent_counts) if recent_counts else None,
            trend_direction=self._detect_trend(counts)
        )
    
    async def get_short_stats(self, duration_hours: int) -> Optional[HistoricalStats]:
        """Calculate statistics for short-term markets of similar duration."""
        
        # Allow +/- 10% duration match
        min_hours = duration_hours * 0.9
        max_hours = duration_hours * 1.1
        
        rows = await self.db.fetch_all("""
            SELECT final_count, tweets_per_hour, start_date
            FROM tweet_history
            WHERE market_type = 'short'
            AND duration_hours BETWEEN ? AND ?
            ORDER BY start_date DESC
        """, (min_hours, max_hours))
        
        if len(rows) < 3:
            # Fall back to per-hour rate from all short markets
            return await self._get_hourly_rate_stats(duration_hours)
        
        counts = [r['final_count'] for r in rows]
        return self._build_stats(counts)
    
    async def get_day_of_week_patterns(self) -> dict:
        """Analyze tweet patterns by day of week."""
        
        rows = await self.db.fetch_all("""
            SELECT day_of_week, AVG(tweet_count) as avg_tweets,
                   COUNT(*) as sample_size
            FROM daily_tweet_counts
            GROUP BY day_of_week
            HAVING sample_size >= 3
        """)
        
        # Returns: {0: 72.5, 1: 68.3, ...} (Mon=0, Sun=6)
        return {r['day_of_week']: r['avg_tweets'] for r in rows}
    
    def _percentile(self, data: list, p: int) -> float:
        """Calculate percentile."""
        sorted_data = sorted(data)
        k = (len(sorted_data) - 1) * p / 100
        f = int(k)
        c = f + 1 if f + 1 < len(sorted_data) else f
        return sorted_data[f] + (sorted_data[c] - sorted_data[f]) * (k - f)
    
    def _detect_trend(self, counts: list) -> str:
        """Detect if tweet counts are trending up, down, or stable."""
        if len(counts) < 4:
            return 'stable'
        
        recent = statistics.mean(counts[:4])
        older = statistics.mean(counts[4:8]) if len(counts) >= 8 else statistics.mean(counts[4:])
        
        change_pct = (recent - older) / older * 100 if older > 0 else 0
        
        if change_pct > 10:
            return 'increasing'
        elif change_pct < -10:
            return 'decreasing'
        return 'stable'
```

### 3.2 Enhanced Projection Engine

```python
# core/learning/smart_projection.py

from dataclasses import dataclass
from typing import Optional
from datetime import datetime, UTC

@dataclass  
class SmartProjection:
    """A projection with confidence intervals based on learned data."""
    center: int
    low: int   # 80% confidence lower bound
    high: int  # 80% confidence upper bound
    
    confidence: str  # 'high', 'medium', 'low'
    confidence_score: float  # 0.0 to 1.0
    
    method: str  # 'live_pace', 'historical_learned', 'historical_fallback'
    sample_size: int  # How many historical data points informed this
    
    reasoning: str  # Human-readable explanation


class SmartProjectionEngine:
    def __init__(self, db, stats_calculator, xtracker_client):
        self.db = db
        self.stats = stats_calculator
        self.xtracker = xtracker_client
        
        # Fallback values (used only when no learned data exists)
        self.FALLBACK_WEEKLY_CENTER = 480
        self.FALLBACK_WEEKLY_STDDEV = 120
    
    async def project(self, market: Market) -> SmartProjection:
        """Generate a projection using the best available method."""
        
        now = datetime.now(UTC)
        market_started = now >= market.start_date
        
        # Method 1: Live pace (best - when we have current data)
        if market_started:
            live_data = await self.xtracker.get_tweet_count(
                market.start_date, 
                market.end_date
            )
            if live_data and live_data.count > 0:
                return await self._project_from_live_pace(market, live_data)
        
        # Method 2: Learned historical (good - when we have past data)
        historical_stats = await self._get_relevant_stats(market)
        if historical_stats and historical_stats.sample_size >= 5:
            return self._project_from_learned_history(market, historical_stats)
        
        # Method 3: Fallback (poor - no learned data yet)
        return self._project_from_fallback(market, historical_stats)
    
    async def _project_from_live_pace(
        self, 
        market: Market, 
        live_data
    ) -> SmartProjection:
        """Project using current tweet pace + historical variance."""
        
        now = datetime.now(UTC)
        elapsed_hours = (now - market.start_date).total_seconds() / 3600
        total_hours = (market.end_date - market.start_date).total_seconds() / 3600
        pct_complete = elapsed_hours / total_hours
        
        # Current pace projection
        pace_per_hour = live_data.count / elapsed_hours
        projected_final = int(pace_per_hour * total_hours)
        
        # Get historical variance to set confidence interval
        stats = await self._get_relevant_stats(market)
        
        if stats and stats.sample_size >= 5:
            # Use learned variance, but narrow it based on how much data we have
            # More complete = tighter interval
            variance_factor = 1.0 - (pct_complete * 0.7)  # 100% complete -> 30% of historical variance
            adjusted_stddev = stats.std_dev * variance_factor
            
            return SmartProjection(
                center=projected_final,
                low=int(projected_final - 1.3 * adjusted_stddev),  # ~80% CI
                high=int(projected_final + 1.3 * adjusted_stddev),
                confidence='high' if pct_complete > 0.5 else 'medium',
                confidence_score=min(0.9, 0.5 + pct_complete * 0.5),
                method='live_pace',
                sample_size=stats.sample_size,
                reasoning=f"Live pace: {pace_per_hour:.1f}/hr, {pct_complete*100:.0f}% complete. "
                         f"Variance from {stats.sample_size} historical markets."
            )
        else:
            # No historical data - use wider default interval
            interval = projected_final * 0.15 * (1 - pct_complete)
            
            return SmartProjection(
                center=projected_final,
                low=int(projected_final - interval),
                high=int(projected_final + interval),
                confidence='medium',
                confidence_score=0.5 + pct_complete * 0.3,
                method='live_pace',
                sample_size=0,
                reasoning=f"Live pace: {pace_per_hour:.1f}/hr. No historical data for variance."
            )
    
    def _project_from_learned_history(
        self, 
        market: Market, 
        stats: HistoricalStats
    ) -> SmartProjection:
        """Project using learned historical patterns (no live data yet)."""
        
        # Adjust center based on recent trend
        if stats.trend_direction == 'increasing' and stats.recent_mean:
            center = int(stats.recent_mean)  # Weight recent weeks
        elif stats.trend_direction == 'decreasing' and stats.recent_mean:
            center = int(stats.recent_mean)
        else:
            center = int(stats.mean)
        
        # Use percentiles for confidence interval (80% range: p10 to p90)
        return SmartProjection(
            center=center,
            low=int(stats.p10),
            high=int(stats.p90),
            confidence='medium',
            confidence_score=min(0.7, 0.3 + stats.sample_size * 0.04),  # More data = more confident
            method='historical_learned',
            sample_size=stats.sample_size,
            reasoning=f"Based on {stats.sample_size} past markets. "
                     f"Mean: {stats.mean:.0f}, StdDev: {stats.std_dev:.0f}. "
                     f"Trend: {stats.trend_direction}."
        )
    
    def _project_from_fallback(
        self, 
        market: Market,
        partial_stats: Optional[HistoricalStats]
    ) -> SmartProjection:
        """Fallback projection when insufficient data exists."""
        
        if partial_stats and partial_stats.sample_size > 0:
            # We have SOME data, just not enough for confidence
            center = int(partial_stats.mean)
            stddev = partial_stats.std_dev if partial_stats.std_dev > 0 else self.FALLBACK_WEEKLY_STDDEV
            sample_size = partial_stats.sample_size
            reasoning = f"Limited data: only {sample_size} markets. Using wide interval."
        else:
            # No data at all - use hardcoded fallback
            center = self.FALLBACK_WEEKLY_CENTER
            stddev = self.FALLBACK_WEEKLY_STDDEV
            sample_size = 0
            reasoning = "No historical data yet. Using default estimates."
        
        return SmartProjection(
            center=center,
            low=int(center - 2 * stddev),  # Very wide interval
            high=int(center + 2 * stddev),
            confidence='low',
            confidence_score=0.2,
            method='historical_fallback',
            sample_size=sample_size,
            reasoning=reasoning
        )
    
    async def _get_relevant_stats(self, market: Market) -> Optional[HistoricalStats]:
        """Get historical stats relevant to this market type."""
        
        if market.duration_type == 'weekly':
            return await self.stats.get_weekly_stats()
        else:
            duration_hours = (market.end_date - market.start_date).total_seconds() / 3600
            return await self.stats.get_short_stats(int(duration_hours))
```

---

## 4. Entry Decision Logic

### 4.1 Confidence-Based Entry Criteria

```python
# core/learning/entry_advisor.py

@dataclass
class EntryAdvice:
    should_enter: bool
    reason: str
    recommended_buckets: list
    position_size_multiplier: float  # 1.0 = normal, 0.5 = half size, etc.


class EntryAdvisor:
    def __init__(self, settings: dict):
        self.settings = settings
        
        # Minimum confidence to enter
        self.MIN_CONFIDENCE_SCORE = 0.4
        
        # Confidence thresholds for position sizing
        self.HIGH_CONFIDENCE_THRESHOLD = 0.7
        self.MEDIUM_CONFIDENCE_THRESHOLD = 0.5
    
    def advise(self, market: Market, projection: SmartProjection, bucket_prices: dict) -> EntryAdvice:
        """Decide whether to enter and with what parameters."""
        
        # Rule 1: Don't enter with low confidence unless we're desperate
        if projection.confidence_score < self.MIN_CONFIDENCE_SCORE:
            if projection.method == 'historical_fallback':
                return EntryAdvice(
                    should_enter=False,
                    reason=f"Confidence too low ({projection.confidence_score:.0%}). "
                           f"Waiting for more data. {projection.reasoning}",
                    recommended_buckets=[],
                    position_size_multiplier=0
                )
        
        # Rule 2: Select buckets based on projection range
        selected_buckets = self._select_buckets(projection, bucket_prices)
        
        if not selected_buckets:
            return EntryAdvice(
                should_enter=False,
                reason="No buckets available within projection range at acceptable prices.",
                recommended_buckets=[],
                position_size_multiplier=0
            )
        
        # Rule 3: Adjust position size based on confidence
        if projection.confidence_score >= self.HIGH_CONFIDENCE_THRESHOLD:
            size_mult = 1.0
        elif projection.confidence_score >= self.MEDIUM_CONFIDENCE_THRESHOLD:
            size_mult = 0.7
        else:
            size_mult = 0.5
        
        return EntryAdvice(
            should_enter=True,
            reason=f"Entering with {projection.confidence} confidence. {projection.reasoning}",
            recommended_buckets=selected_buckets,
            position_size_multiplier=size_mult
        )
    
    def _select_buckets(self, projection: SmartProjection, bucket_prices: dict) -> list:
        """Select buckets within projection range and under max price."""
        
        max_price = self.settings.get('max_entry_price_weekly', 0.10)
        
        # Tighter range for higher confidence
        if projection.confidence_score >= 0.7:
            buffer = 20  # +/- 20 from bounds
        elif projection.confidence_score >= 0.5:
            buffer = 30
        else:
            buffer = 40
        
        range_low = projection.low - buffer
        range_high = projection.high + buffer
        
        candidates = []
        for bucket_range, data in bucket_prices.items():
            midpoint = self._get_bucket_midpoint(bucket_range)
            
            if range_low <= midpoint <= range_high and data['yes_price'] <= max_price:
                distance_from_center = abs(midpoint - projection.center)
                value_score = (1 - data['yes_price']) / data['yes_price']  # Higher = better value
                
                candidates.append({
                    'bucket': bucket_range,
                    'price': data['yes_price'],
                    'distance': distance_from_center,
                    'priority': value_score - (distance_from_center / 100)  # Prefer center + cheap
                })
        
        # Sort by priority, take top N
        candidates.sort(key=lambda x: x['priority'], reverse=True)
        max_buckets = self.settings.get('max_buckets_per_market', 10)
        
        return candidates[:max_buckets]
    
    def _get_bucket_midpoint(self, bucket_range: str) -> int:
        low, high = map(int, bucket_range.split('-'))
        return (low + high) // 2
```

---

## 5. Backfill Historical Data

To bootstrap the learning system, we should backfill data from past resolved markets:

```python
# scripts/backfill_history.py

async def backfill_historical_data():
    """Fetch and store historical market outcomes from Polymarket."""
    
    # Get all resolved Elon tweet markets
    resolved_markets = await polymarket.get_resolved_markets(
        tag="elon-musk-tweets",
        limit=100
    )
    
    for market in resolved_markets:
        # Extract final count from winning bucket
        winning_bucket = market.winning_outcome  # e.g., "480-499"
        midpoint = get_bucket_midpoint(winning_bucket)
        
        # For exact count, we'd need to check xTracker archives or market resolution data
        # Approximation: use bucket midpoint
        estimated_final = midpoint
        
        await data_collector.record_market_outcome(
            market=market,
            final_count=estimated_final,
            winning_bucket=winning_bucket
        )
        
        print(f"Backfilled: {market.question} -> {winning_bucket}")
```

---

## 6. Integration Points

### 6.1 Modify bot.py Scan Cycle

```python
# In bot.py run_scan_cycle()

async def run_scan_cycle(self):
    markets = await self.scanner.scan_markets()
    
    for market in markets:
        # Use NEW smart projection engine
        projection = await self.smart_projection_engine.project(market)
        
        # Log projection for learning
        await self.data_collector.record_prediction(market, projection)
        
        # Get entry advice (confidence-aware)
        bucket_prices = await self.get_bucket_prices(market)
        advice = self.entry_advisor.advise(market, projection, bucket_prices)
        
        if not advice.should_enter:
            self.log.info("entry_skipped", 
                market=market.id, 
                reason=advice.reason,
                confidence=projection.confidence_score)
            continue
        
        # Execute with adjusted position size
        await self.execute_entries(
            market, 
            advice.recommended_buckets,
            size_multiplier=advice.position_size_multiplier
        )
```

### 6.2 Modify Resolution Handler

```python
# In resolution_checker.py

async def handle_resolution(self, market: Market, outcome: str):
    # Existing logic to claim winnings...
    
    # NEW: Record outcome for learning
    final_count = self._extract_count_from_outcome(outcome)
    await self.data_collector.record_market_outcome(
        market=market,
        final_count=final_count,
        winning_bucket=outcome
    )
    
    # NEW: Update prediction accuracy
    await self.data_collector.update_prediction_outcomes(
        market_id=market.id,
        actual_final=final_count
    )
```

---

## 7. Dashboard Additions

Add a "Learning Stats" section to the dashboard:

```python
# api/routes/learning.py

@router.get("/learning/stats")
async def get_learning_stats():
    stats = await stats_calculator.get_weekly_stats()
    
    return {
        "weekly_markets": {
            "sample_size": stats.sample_size if stats else 0,
            "mean": stats.mean if stats else None,
            "std_dev": stats.std_dev if stats else None,
            "range": f"{stats.min_count}-{stats.max_count}" if stats else None,
            "trend": stats.trend_direction if stats else None
        },
        "prediction_accuracy": await get_prediction_accuracy(),
        "confidence_calibration": await get_calibration_stats()
    }

async def get_prediction_accuracy():
    """How accurate have our predictions been?"""
    
    rows = await db.fetch_all("""
        SELECT 
            confidence,
            COUNT(*) as total,
            AVG(ABS(prediction_error)) as avg_error,
            SUM(CASE WHEN within_range THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pct_in_range
        FROM prediction_outcomes
        WHERE actual_final IS NOT NULL
        GROUP BY confidence
    """)
    
    return {r['confidence']: {
        'total_predictions': r['total'],
        'avg_error': r['avg_error'],
        'pct_within_range': r['pct_in_range']
    } for r in rows}
```

---

## 8. Implementation Order

### Phase 1: Data Collection (Do First)
1. Add database tables
2. Implement `record_market_outcome()` in resolution handler
3. Implement `record_daily_snapshot()` in tweet count updater
4. Run backfill script for historical markets

### Phase 2: Statistics Engine
1. Implement `StatsCalculator`
2. Add `/learning/stats` API endpoint
3. Add Learning Stats section to dashboard

### Phase 3: Smart Projections
1. Implement `SmartProjectionEngine`
2. Implement `EntryAdvisor`
3. Integrate into scan cycle
4. Add prediction logging

### Phase 4: Calibration & Tuning
1. Monitor prediction accuracy
2. Adjust confidence thresholds based on real performance
3. Add day-of-week patterns if sample size sufficient

---

## 9. Expected Improvement Timeline

| Weeks of Data | Sample Size | Expected Confidence | Projection Range |
|---------------|-------------|--------------------:|------------------|
| 0-2           | 0-2         | Low (fallback)      | ±240 tweets      |
| 3-5           | 3-5         | Low-Medium          | ±150 tweets      |
| 6-10          | 6-10        | Medium              | ±100 tweets      |
| 10-20         | 10-20       | Medium-High         | ±70 tweets       |
| 20+           | 20+         | High                | ±50 tweets       |

The bot will get meaningfully smarter after ~6 weeks of data collection, and reach peak performance after ~20 weeks.

---

## 10. Risk Management Integration

The learning system also enables smarter risk management:

```python
def calculate_kelly_fraction(projection: SmartProjection, bucket_price: float) -> float:
    """Calculate optimal bet size using Kelly Criterion."""
    
    # Estimate win probability based on distance from center
    # This is a simplification - real implementation would use distribution
    
    if projection.confidence_score < 0.4:
        return 0.25  # Quarter Kelly when uncertain
    elif projection.confidence_score < 0.7:
        return 0.5   # Half Kelly
    else:
        return 0.75  # Three-quarter Kelly (never full Kelly)
```

---

This design creates a bot that starts cautious, learns from every market, and becomes increasingly confident and accurate over time. The key insight is that **the bot should know what it doesn't know** — and be appropriately conservative until it has enough data to make informed decisions.
