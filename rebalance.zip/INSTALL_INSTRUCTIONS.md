# ElonBot Rebalance Manager - Installation Instructions

## Overview

This update adds a **Rebalance Manager** to ElonBot that implements the hybrid entry/exit strategy:

1. **Phase 1 (Entry)**: Buy cheap across multiple buckets when market opens (existing behavior)
2. **Phase 2 (Monitor)**: Watch live tweet pace from xTracker (existing behavior)
3. **Phase 3 (Rebalance)**: NEW - Sell positions outside projected range while still profitable
4. **Phase 4 (Hold)**: Hold remaining positions to resolution

## Files to Add

### 1. Core Module: `core/rebalance_manager.py`
This is the main logic file. Copy the entire contents to `/home/ubuntu/elonbot/core/rebalance_manager.py`

### 2. API Routes: Add to `dashboard/routes/api.py`
Add the rebalance endpoints to your existing API routes file. The key endpoints are:
- `GET /api/rebalance/analysis` - Get analysis for all markets
- `GET /api/rebalance/analysis/{market_id}` - Get analysis for specific market
- `POST /api/rebalance/execute` - Execute rebalancing
- `POST /api/rebalance/sell/{market_id}/{bucket_range}` - Quick sell single position

### 3. Dashboard UI: Add to `dashboard/templates/index.html`
Add the Rebalance Analysis section after the Positions section.

### 4. Scheduler Job: Add to `scheduler.py` or `bot.py`
Add the rebalance check job that runs every 30 minutes.

## Database Settings to Add

Run these SQL statements to add the new settings:

```sql
INSERT OR IGNORE INTO settings (key, value) VALUES
    ('rebalance_enabled', 'true'),
    ('rebalance_auto_sell', 'false'),
    ('rebalance_min_profit_pct', '20'),
    ('rebalance_min_progress_pct', '20');
```

## Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| `rebalance_enabled` | true | Enable/disable rebalance analysis |
| `rebalance_auto_sell` | false | Auto-execute sells (recommend keeping false initially) |
| `rebalance_min_profit_pct` | 20 | Minimum profit % to sell outside positions |
| `rebalance_min_progress_pct` | 20 | Don't rebalance until market is X% complete |

## How the Rebalancing Logic Works

### Viability Classification

Each position is classified based on current projection:
- **GOOD**: Bucket contains the projected final count (HOLD)
- **BORDERLINE**: Within 1-2 buckets of projection (usually HOLD)
- **OUTSIDE**: 2-5 buckets away from projection (SELL if profitable)
- **FAR_OUTSIDE**: 5+ buckets away (SELL even at breakeven after 50% complete)

### Sell Decision Matrix

| Viability | Market Progress | Profit Required | Action |
|-----------|-----------------|-----------------|--------|
| GOOD | Any | N/A | HOLD |
| BORDERLINE | < 50% | 100%+ | SELL |
| BORDERLINE | > 50% | 100%+ | SELL |
| OUTSIDE | < 50% | 50%+ | SELL |
| OUTSIDE | 50-75% | 20%+ | SELL |
| OUTSIDE | > 75% | 0%+ | SELL |
| FAR_OUTSIDE | < 50% | 0%+ | SELL |
| FAR_OUTSIDE | > 50% | Any (even loss) | SELL |

### Example Scenario

**Jan 20-27 Market:**
- You bought buckets 320-439 and 620-699 at 2-3¢
- Day 2: Projection shows 152 tweets (bucket 140-159)
- Analysis:
  - 320-439: FAR_OUTSIDE (projection is 152, these start at 320)
  - 620-699: FAR_OUTSIDE
- Recommendation: SELL ALL, they're currently up 50-100% but will go to zero
- Action: Sell for ~5¢ each, recover capital, optionally buy 140-159

## Integration Steps

### Step 1: Add the rebalance_manager.py file

```bash
# Copy rebalance_manager.py to core/
cp rebalance_manager.py /home/ubuntu/elonbot/core/
```

### Step 2: Update api.py

Add imports at the top:
```python
from core.rebalance_manager import RebalanceManager, format_recommendation
```

Add the API endpoints from `rebalance_api.py`.

### Step 3: Update index.html

Add the rebalance section HTML and CSS from `rebalance_component.html`.

### Step 4: Update app.js

Add the JavaScript functions from `rebalance_component.html`.

### Step 5: Add scheduler job

Add to your scheduler setup:
```python
scheduler.add_job(
    rebalance_check_job,
    'interval',
    minutes=30,
    id='rebalance_check',
    name='Rebalance Check',
    replace_existing=True
)
```

### Step 6: Add database settings

```bash
sqlite3 /home/ubuntu/elonbot/data/elonbot.db
```

```sql
INSERT OR IGNORE INTO settings (key, value) VALUES
    ('rebalance_enabled', 'true'),
    ('rebalance_auto_sell', 'false'),
    ('rebalance_min_profit_pct', '20'),
    ('rebalance_min_progress_pct', '20');
```

### Step 7: Restart bot

```bash
pkill -f "python3 bot.py"
cd /home/ubuntu/elonbot
nohup python3 bot.py > logs/bot.log 2>&1 &
```

## Testing

1. Visit the dashboard at `http://13.61.145.121:5025`
2. Look for the new "Rebalance Analysis" section
3. It should show your current positions with viability indicators
4. If positions are outside the projected range, you'll see "Action Recommended"
5. Use the "Sell" buttons to manually sell positions

## Important Notes

1. **Auto-sell is disabled by default** - Use the dashboard to manually approve sells until you're confident in the logic

2. **The bot won't auto-buy replacement positions** - This is intentional. After selling, you can manually decide whether to re-enter closer to projection.

3. **Rebalancing only starts after 20% market progress** - This gives time for the projection to stabilize

4. **Confidence increases with time** - Early projections are less reliable, so the bot is more conservative early on

## Monitoring

Check the activity log for rebalance events:
```sql
SELECT * FROM activity_log 
WHERE event_type LIKE 'REBALANCE%' 
ORDER BY created_at DESC 
LIMIT 20;
```

## Rollback

If you need to disable rebalancing:
```sql
UPDATE settings SET value = 'false' WHERE key = 'rebalance_enabled';
```
