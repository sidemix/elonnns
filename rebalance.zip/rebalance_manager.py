"""
Rebalance Manager for ElonBot

This module implements the hybrid entry/exit strategy:
1. Buy cheap across multiple buckets when market opens
2. Monitor live tweet pace from xTracker
3. Sell positions that fall outside projected range (while still profitable)
4. Optionally buy positions closer to current projection

The goal is to capture gains on "wrong" buckets before they go to zero,
while maintaining/increasing exposure to likely winning buckets.
"""

import logging
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Optional
from enum import Enum

logger = logging.getLogger(__name__)


class PositionViability(Enum):
    """How likely a position is to win based on current projection."""
    GOOD = "good"           # Bucket contains projected final
    BORDERLINE = "borderline"  # Within 1 bucket of projection
    OUTSIDE = "outside"     # 2+ buckets away from projection
    FAR_OUTSIDE = "far_outside"  # 5+ buckets away, very unlikely


class RebalanceAction(Enum):
    """Actions the rebalancer can recommend."""
    HOLD = "hold"
    SELL = "sell"
    BUY_MORE = "buy_more"


@dataclass
class PositionAnalysis:
    """Analysis of a single position's viability and recommended action."""
    market_id: str
    bucket_range: str
    bucket_low: int
    bucket_high: int
    shares: float
    avg_price: float
    current_price: float
    cost_basis: float
    current_value: float
    unrealized_pnl: float
    unrealized_pnl_pct: float
    projected_final: int
    distance_from_projection: int  # How many tweets away from bucket center
    viability: PositionViability
    action: RebalanceAction
    reason: str


@dataclass
class RebalanceRecommendation:
    """Complete rebalancing recommendation for a market."""
    market_id: str
    market_title: str
    current_count: int
    projected_final: int
    target_bucket: str
    hours_elapsed: float
    hours_remaining: float
    confidence: float  # How confident we are in the projection (0-1)
    
    positions_to_sell: list[PositionAnalysis]
    positions_to_hold: list[PositionAnalysis]
    positions_to_buy: list[dict]  # New buckets to buy
    
    total_sell_value: float
    total_buy_cost: float
    net_rebalance_cost: float
    
    should_rebalance: bool
    rebalance_reason: str


class RebalanceManager:
    """
    Manages position rebalancing based on live tweet projections.
    
    Strategy:
    - Check positions every 30 minutes (or on-demand)
    - After market is 20%+ complete, start evaluating exits
    - Sell positions that are "far_outside" projection and currently profitable
    - Sell positions that are "outside" when market is 50%+ complete
    - Optionally re-enter with better positioned buckets
    """
    
    # Configuration
    MIN_MARKET_PROGRESS_FOR_REBALANCE = 0.20  # Don't rebalance until 20% complete
    AGGRESSIVE_REBALANCE_THRESHOLD = 0.50     # More aggressive selling after 50%
    FINAL_REBALANCE_THRESHOLD = 0.75          # Very aggressive after 75%
    
    MIN_PROFIT_PCT_TO_SELL = 0.20             # Only sell if up at least 20%
    MIN_PROFIT_PCT_AGGRESSIVE = 0.0           # Sell at breakeven when aggressive
    
    BUCKET_SIZE = 20  # Standard bucket size (e.g., 320-339 = 20 tweet range)
    
    def __init__(self, db, tweet_scanner, polymarket_client, settings_getter):
        """
        Initialize the RebalanceManager.
        
        Args:
            db: Database connection
            tweet_scanner: TweetScanner instance for live projections
            polymarket_client: PolymarketClient for trading
            settings_getter: Callable that returns current settings dict
        """
        self.db = db
        self.tweet_scanner = tweet_scanner
        self.polymarket_client = polymarket_client
        self.get_settings = settings_getter
    
    def parse_bucket_range(self, bucket_str: str) -> tuple[int, int]:
        """Parse '320-339' into (320, 339)."""
        try:
            parts = bucket_str.split('-')
            return int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            logger.error(f"Failed to parse bucket range: {bucket_str}")
            return 0, 0
    
    def get_bucket_center(self, bucket_low: int, bucket_high: int) -> int:
        """Get the center of a bucket range."""
        return (bucket_low + bucket_high) // 2
    
    def calculate_viability(
        self, 
        bucket_low: int, 
        bucket_high: int, 
        projected_final: int,
        market_progress: float
    ) -> PositionViability:
        """
        Determine how viable a position is based on current projection.
        
        Args:
            bucket_low: Lower bound of bucket (e.g., 320)
            bucket_high: Upper bound of bucket (e.g., 339)
            projected_final: Current projected tweet count
            market_progress: How far through the market we are (0-1)
        """
        # Check if projection falls within bucket
        if bucket_low <= projected_final <= bucket_high:
            return PositionViability.GOOD
        
        # Calculate distance in buckets
        bucket_center = self.get_bucket_center(bucket_low, bucket_high)
        distance = abs(projected_final - bucket_center)
        buckets_away = distance / self.BUCKET_SIZE
        
        # As market progresses, be stricter about viability
        if market_progress < 0.5:
            # Early in market - more tolerance
            if buckets_away <= 2:
                return PositionViability.BORDERLINE
            elif buckets_away <= 5:
                return PositionViability.OUTSIDE
            else:
                return PositionViability.FAR_OUTSIDE
        else:
            # Later in market - less tolerance
            if buckets_away <= 1:
                return PositionViability.BORDERLINE
            elif buckets_away <= 3:
                return PositionViability.OUTSIDE
            else:
                return PositionViability.FAR_OUTSIDE
    
    def should_sell_position(
        self,
        viability: PositionViability,
        unrealized_pnl_pct: float,
        market_progress: float,
        current_price: float
    ) -> tuple[bool, str]:
        """
        Determine if a position should be sold.
        
        Returns:
            (should_sell, reason)
        """
        settings = self.get_settings()
        
        # Never sell GOOD positions
        if viability == PositionViability.GOOD:
            return False, "Position is in projected winning range"
        
        # Don't rebalance too early
        if market_progress < self.MIN_MARKET_PROGRESS_FOR_REBALANCE:
            return False, f"Too early to rebalance ({market_progress:.0%} complete)"
        
        # FAR_OUTSIDE positions - sell if profitable at all
        if viability == PositionViability.FAR_OUTSIDE:
            if unrealized_pnl_pct >= 0:
                return True, f"Far outside projection, locking in {unrealized_pnl_pct:.0%} gain"
            elif market_progress > self.AGGRESSIVE_REBALANCE_THRESHOLD:
                return True, f"Far outside projection at {market_progress:.0%} complete, cutting losses"
            else:
                return False, "Far outside but holding for potential recovery"
        
        # OUTSIDE positions - sell based on market progress and profit
        if viability == PositionViability.OUTSIDE:
            if market_progress > self.FINAL_REBALANCE_THRESHOLD:
                # Very late - sell anything outside
                if unrealized_pnl_pct >= self.MIN_PROFIT_PCT_AGGRESSIVE:
                    return True, f"Outside projection at {market_progress:.0%} complete"
            elif market_progress > self.AGGRESSIVE_REBALANCE_THRESHOLD:
                # Aggressive phase - sell if profitable
                if unrealized_pnl_pct >= self.MIN_PROFIT_PCT_TO_SELL:
                    return True, f"Outside projection, taking {unrealized_pnl_pct:.0%} profit"
            # Early aggressive phase - only sell if nicely profitable
            elif unrealized_pnl_pct >= 0.50:  # 50%+ gain
                return True, f"Outside projection but locking in {unrealized_pnl_pct:.0%} gain"
        
        # BORDERLINE positions - generally hold unless very profitable
        if viability == PositionViability.BORDERLINE:
            if unrealized_pnl_pct >= 1.0 and market_progress > self.AGGRESSIVE_REBALANCE_THRESHOLD:
                return True, f"Borderline position, taking {unrealized_pnl_pct:.0%} profit"
        
        return False, "Holding position"
    
    async def analyze_position(
        self,
        position: dict,
        projected_final: int,
        market_progress: float,
        current_prices: dict
    ) -> PositionAnalysis:
        """
        Analyze a single position and determine recommended action.
        
        Args:
            position: Position dict from database
            projected_final: Current projected tweet count
            market_progress: How far through market (0-1)
            current_prices: Dict of bucket -> price info
        """
        bucket_range = position['bucket_range']
        bucket_low, bucket_high = self.parse_bucket_range(bucket_range)
        bucket_center = self.get_bucket_center(bucket_low, bucket_high)
        
        shares = position['shares']
        avg_price = position['avg_price']
        cost_basis = shares * avg_price
        
        # Get current price
        current_price = avg_price  # Default to avg if not found
        if bucket_range in current_prices:
            current_price = current_prices[bucket_range].get('yes_price', avg_price)
        
        current_value = shares * current_price
        unrealized_pnl = current_value - cost_basis
        unrealized_pnl_pct = unrealized_pnl / cost_basis if cost_basis > 0 else 0
        
        # Calculate viability
        viability = self.calculate_viability(
            bucket_low, bucket_high, projected_final, market_progress
        )
        
        # Determine action
        should_sell, reason = self.should_sell_position(
            viability, unrealized_pnl_pct, market_progress, current_price
        )
        
        if should_sell:
            action = RebalanceAction.SELL
        else:
            action = RebalanceAction.HOLD
        
        return PositionAnalysis(
            market_id=position['market_id'],
            bucket_range=bucket_range,
            bucket_low=bucket_low,
            bucket_high=bucket_high,
            shares=shares,
            avg_price=avg_price,
            current_price=current_price,
            cost_basis=cost_basis,
            current_value=current_value,
            unrealized_pnl=unrealized_pnl,
            unrealized_pnl_pct=unrealized_pnl_pct,
            projected_final=projected_final,
            distance_from_projection=abs(projected_final - bucket_center),
            viability=viability,
            action=action,
            reason=reason
        )
    
    def calculate_confidence(self, hours_elapsed: float, total_hours: float) -> float:
        """
        Calculate confidence in projection based on time elapsed.
        
        More time elapsed = more data = higher confidence.
        """
        if total_hours <= 0:
            return 0.0
        
        progress = hours_elapsed / total_hours
        
        # Confidence curve: starts low, increases with sqrt of progress
        # At 25% complete: ~50% confidence
        # At 50% complete: ~70% confidence
        # At 75% complete: ~87% confidence
        confidence = min(1.0, progress ** 0.5)
        
        return confidence
    
    def identify_buckets_to_buy(
        self,
        projected_final: int,
        current_prices: dict,
        existing_buckets: set[str],
        max_price: float,
        max_buckets: int = 3
    ) -> list[dict]:
        """
        Identify new buckets to buy that are closer to current projection.
        
        Args:
            projected_final: Current projected tweet count
            current_prices: Dict of bucket -> price info
            existing_buckets: Set of bucket ranges we already own
            max_price: Maximum price to pay per share
            max_buckets: Maximum new buckets to recommend
        """
        candidates = []
        
        for bucket_range, price_info in current_prices.items():
            # Skip buckets we already own
            if bucket_range in existing_buckets:
                continue
            
            yes_price = price_info.get('yes_price', 1.0)
            
            # Skip if too expensive
            if yes_price > max_price:
                continue
            
            bucket_low, bucket_high = self.parse_bucket_range(bucket_range)
            bucket_center = self.get_bucket_center(bucket_low, bucket_high)
            distance = abs(projected_final - bucket_center)
            
            # Only consider buckets within 2 bucket-widths of projection
            if distance <= self.BUCKET_SIZE * 2:
                candidates.append({
                    'bucket_range': bucket_range,
                    'price': yes_price,
                    'distance': distance,
                    'token_id': price_info.get('token_id'),
                    'in_range': bucket_low <= projected_final <= bucket_high
                })
        
        # Sort by: in_range first, then by distance, then by price
        candidates.sort(key=lambda x: (not x['in_range'], x['distance'], x['price']))
        
        return candidates[:max_buckets]
    
    async def analyze_market(self, market_id: str) -> Optional[RebalanceRecommendation]:
        """
        Analyze a market and generate rebalancing recommendation.
        
        Args:
            market_id: The market ID to analyze
            
        Returns:
            RebalanceRecommendation or None if analysis fails
        """
        try:
            # Get market info from database
            cursor = self.db.execute(
                "SELECT * FROM markets WHERE id = ?",
                (market_id,)
            )
            market = cursor.fetchone()
            
            if not market:
                logger.warning(f"Market {market_id} not found in database")
                return None
            
            market = dict(market)
            
            # Get our positions in this market
            cursor = self.db.execute(
                "SELECT * FROM positions WHERE market_id = ? AND status = 'open'",
                (market_id,)
            )
            positions = [dict(row) for row in cursor.fetchall()]
            
            if not positions:
                logger.info(f"No open positions in market {market_id}")
                return None
            
            # Get live tracking data
            tracking_data = await self.tweet_scanner.get_current_counts()
            
            # Find matching tracking period
            market_tracking = None
            for tracking_id, data in tracking_data.items():
                # Match by market_id if stored, or by date matching
                if data.get('market_id') == market_id:
                    market_tracking = data
                    break
            
            if not market_tracking:
                logger.warning(f"No live tracking data for market {market_id}")
                return None
            
            # Extract tracking info
            current_count = market_tracking.get('current_count', 0)
            projected_final = market_tracking.get('projected_final', 0)
            target_bucket = market_tracking.get('projected_bucket', 'unknown')
            hours_elapsed = market_tracking.get('hours_elapsed', 0)
            hours_remaining = market_tracking.get('hours_remaining', 0)
            total_hours = hours_elapsed + hours_remaining
            
            market_progress = hours_elapsed / total_hours if total_hours > 0 else 0
            confidence = self.calculate_confidence(hours_elapsed, total_hours)
            
            # Get current prices
            try:
                current_prices = await self.polymarket_client.get_market_prices(market_id)
            except Exception as e:
                logger.error(f"Failed to get prices for market {market_id}: {e}")
                current_prices = {}
            
            # Analyze each position
            positions_to_sell = []
            positions_to_hold = []
            
            for position in positions:
                analysis = await self.analyze_position(
                    position, projected_final, market_progress, current_prices
                )
                
                if analysis.action == RebalanceAction.SELL:
                    positions_to_sell.append(analysis)
                else:
                    positions_to_hold.append(analysis)
            
            # Identify new buckets to buy (optional)
            settings = self.get_settings()
            max_entry_price = float(settings.get('max_entry_price_weekly', 0.10))
            
            existing_buckets = {p['bucket_range'] for p in positions}
            positions_to_buy = self.identify_buckets_to_buy(
                projected_final,
                current_prices,
                existing_buckets,
                max_entry_price,
                max_buckets=2
            )
            
            # Calculate totals
            total_sell_value = sum(p.current_value for p in positions_to_sell)
            total_buy_cost = sum(
                float(settings.get('bet_size_per_bucket', 10)) 
                for _ in positions_to_buy
            )
            net_rebalance_cost = total_buy_cost - total_sell_value
            
            # Determine if we should rebalance
            should_rebalance = len(positions_to_sell) > 0 or len(positions_to_buy) > 0
            
            if not should_rebalance:
                rebalance_reason = "All positions are well-positioned"
            elif len(positions_to_sell) > 0 and len(positions_to_buy) > 0:
                rebalance_reason = f"Sell {len(positions_to_sell)} outside positions, buy {len(positions_to_buy)} better positioned"
            elif len(positions_to_sell) > 0:
                rebalance_reason = f"Sell {len(positions_to_sell)} positions outside projected range"
            else:
                rebalance_reason = f"Buy {len(positions_to_buy)} positions closer to projection"
            
            return RebalanceRecommendation(
                market_id=market_id,
                market_title=market.get('title', ''),
                current_count=current_count,
                projected_final=projected_final,
                target_bucket=target_bucket,
                hours_elapsed=hours_elapsed,
                hours_remaining=hours_remaining,
                confidence=confidence,
                positions_to_sell=positions_to_sell,
                positions_to_hold=positions_to_hold,
                positions_to_buy=positions_to_buy,
                total_sell_value=total_sell_value,
                total_buy_cost=total_buy_cost,
                net_rebalance_cost=net_rebalance_cost,
                should_rebalance=should_rebalance,
                rebalance_reason=rebalance_reason
            )
            
        except Exception as e:
            logger.error(f"Error analyzing market {market_id}: {e}", exc_info=True)
            return None
    
    async def execute_rebalance(
        self, 
        recommendation: RebalanceRecommendation,
        execute_sells: bool = True,
        execute_buys: bool = False  # Default to not auto-buying
    ) -> dict:
        """
        Execute a rebalancing recommendation.
        
        Args:
            recommendation: The rebalancing recommendation
            execute_sells: Whether to execute sell orders
            execute_buys: Whether to execute buy orders
            
        Returns:
            Dict with results of execution
        """
        results = {
            'sells_executed': [],
            'sells_failed': [],
            'buys_executed': [],
            'buys_failed': [],
            'total_sold': 0.0,
            'total_bought': 0.0,
        }
        
        if not recommendation.should_rebalance:
            logger.info(f"No rebalancing needed for {recommendation.market_id}")
            return results
        
        # Execute sells
        if execute_sells and recommendation.positions_to_sell:
            for position in recommendation.positions_to_sell:
                try:
                    logger.info(
                        f"Selling {position.shares} shares of {position.bucket_range} "
                        f"at ~${position.current_price:.3f} (reason: {position.reason})"
                    )
                    
                    # Place sell order
                    order_result = await self.polymarket_client.place_order(
                        token_id=position.bucket_range,  # Need actual token_id
                        side='sell',
                        price=position.current_price * 0.98,  # Slightly below market
                        size=position.shares,
                        market_id=recommendation.market_id
                    )
                    
                    results['sells_executed'].append({
                        'bucket': position.bucket_range,
                        'shares': position.shares,
                        'price': position.current_price,
                        'value': position.current_value,
                        'order_id': order_result.get('order_id')
                    })
                    results['total_sold'] += position.current_value
                    
                    # Update position status in database
                    self.db.execute(
                        """UPDATE positions 
                           SET status = 'sold', closed_at = ? 
                           WHERE market_id = ? AND bucket_range = ?""",
                        (datetime.now(timezone.utc), recommendation.market_id, position.bucket_range)
                    )
                    self.db.commit()
                    
                    # Log activity
                    self.db.execute(
                        """INSERT INTO activity_log (event_type, message, details)
                           VALUES (?, ?, ?)""",
                        ('REBALANCE_SELL', 
                         f"Sold {position.shares} shares of {position.bucket_range}",
                         f"Price: ${position.current_price:.3f}, P/L: {position.unrealized_pnl_pct:.0%}, Reason: {position.reason}")
                    )
                    self.db.commit()
                    
                except Exception as e:
                    logger.error(f"Failed to sell {position.bucket_range}: {e}")
                    results['sells_failed'].append({
                        'bucket': position.bucket_range,
                        'error': str(e)
                    })
        
        # Execute buys (if enabled)
        if execute_buys and recommendation.positions_to_buy:
            settings = self.get_settings()
            bet_size = float(settings.get('bet_size_per_bucket', 10))
            
            for bucket_info in recommendation.positions_to_buy:
                try:
                    price = bucket_info['price']
                    shares = bet_size / price
                    
                    logger.info(
                        f"Buying {shares:.1f} shares of {bucket_info['bucket_range']} "
                        f"at ${price:.3f}"
                    )
                    
                    # Place buy order
                    order_result = await self.polymarket_client.place_order(
                        token_id=bucket_info['token_id'],
                        side='buy',
                        price=price * 1.02,  # Slightly above market
                        size=shares,
                        market_id=recommendation.market_id
                    )
                    
                    results['buys_executed'].append({
                        'bucket': bucket_info['bucket_range'],
                        'shares': shares,
                        'price': price,
                        'cost': bet_size,
                        'order_id': order_result.get('order_id')
                    })
                    results['total_bought'] += bet_size
                    
                    # Log activity
                    self.db.execute(
                        """INSERT INTO activity_log (event_type, message, details)
                           VALUES (?, ?, ?)""",
                        ('REBALANCE_BUY',
                         f"Bought {shares:.1f} shares of {bucket_info['bucket_range']}",
                         f"Price: ${price:.3f}, Cost: ${bet_size:.2f}")
                    )
                    self.db.commit()
                    
                except Exception as e:
                    logger.error(f"Failed to buy {bucket_info['bucket_range']}: {e}")
                    results['buys_failed'].append({
                        'bucket': bucket_info['bucket_range'],
                        'error': str(e)
                    })
        
        return results
    
    async def check_all_markets(self) -> list[RebalanceRecommendation]:
        """
        Check all markets with open positions for rebalancing opportunities.
        
        Returns:
            List of RebalanceRecommendation objects
        """
        recommendations = []
        
        # Get all markets with open positions
        cursor = self.db.execute(
            """SELECT DISTINCT market_id FROM positions 
               WHERE status = 'open'"""
        )
        market_ids = [row[0] for row in cursor.fetchall()]
        
        for market_id in market_ids:
            recommendation = await self.analyze_market(market_id)
            if recommendation:
                recommendations.append(recommendation)
                
                if recommendation.should_rebalance:
                    logger.info(
                        f"Rebalance opportunity in {market_id}: {recommendation.rebalance_reason}"
                    )
        
        return recommendations


# Utility function for formatting recommendations
def format_recommendation(rec: RebalanceRecommendation) -> str:
    """Format a rebalance recommendation as a human-readable string."""
    lines = [
        f"\n{'='*60}",
        f"REBALANCE ANALYSIS: {rec.market_title}",
        f"{'='*60}",
        f"Current Count: {rec.current_count} tweets",
        f"Projected Final: {rec.projected_final} tweets",
        f"Target Bucket: {rec.target_bucket}",
        f"Progress: {rec.hours_elapsed:.1f}h elapsed, {rec.hours_remaining:.1f}h remaining",
        f"Confidence: {rec.confidence:.0%}",
        f"",
        f"RECOMMENDATION: {rec.rebalance_reason}",
        f""
    ]
    
    if rec.positions_to_sell:
        lines.append("POSITIONS TO SELL:")
        for p in rec.positions_to_sell:
            lines.append(
                f"  - {p.bucket_range}: {p.shares} shares @ ${p.current_price:.3f} "
                f"({p.unrealized_pnl_pct:+.0%}) - {p.reason}"
            )
        lines.append(f"  Total sell value: ${rec.total_sell_value:.2f}")
        lines.append("")
    
    if rec.positions_to_hold:
        lines.append("POSITIONS TO HOLD:")
        for p in rec.positions_to_hold:
            lines.append(
                f"  - {p.bucket_range}: {p.shares} shares @ ${p.current_price:.3f} "
                f"({p.unrealized_pnl_pct:+.0%}) [{p.viability.value}]"
            )
        lines.append("")
    
    if rec.positions_to_buy:
        lines.append("RECOMMENDED BUYS:")
        for b in rec.positions_to_buy:
            in_range = "✓ IN RANGE" if b['in_range'] else ""
            lines.append(
                f"  - {b['bucket_range']}: ${b['price']:.3f} "
                f"(distance: {b['distance']} tweets) {in_range}"
            )
        lines.append(f"  Total buy cost: ${rec.total_buy_cost:.2f}")
        lines.append("")
    
    lines.append(f"Net rebalance cost: ${rec.net_rebalance_cost:+.2f}")
    lines.append("="*60)
    
    return "\n".join(lines)
